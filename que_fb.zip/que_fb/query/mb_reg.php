<?php
require("../config/connect.php");
//member_rb
$mb_email = mysqli_real_escape_string($conn, $_POST['mb_email']);
$mb_pass = mysqli_real_escape_string($conn, $_POST['mb_pass']);
$mb_pass2 = mysqli_real_escape_string($conn, $_POST['mb_pass2']);
$mb_type = mysqli_real_escape_string($conn, $_POST['mb_type']);
$mb_name = mysqli_real_escape_string($conn, $_POST['mb_name']);
$mb_phone = mysqli_real_escape_string($conn, $_POST['mb_phone']);
//address
$ad_name = mysqli_real_escape_string($conn, $_POST['ad_name']);
$ad_detail = mysqli_real_escape_string($conn, $_POST['ad_detail']);
$ad_lat = mysqli_real_escape_string($conn, $_POST['ad_lat']);
$ad_lon = mysqli_real_escape_string($conn, $_POST['ad_lon']);
//กำหนดตัวแปรเพื่อรับรหัสสมาชิก
$mb_code = 0;
//ตรวจค่าพิกัด


//ตรวจการซ้ำของ email
$sqlcheck = "select mb_email from member_rb where mb_email='$mb_email' ";
$result = mysqli_query($conn, $sqlcheck) or die("sqlcheck email error");
$count = mysqli_num_rows($result);
if ($count > 0) {
    js_alert('Email นี้ถูกใช้ไปแล้ว กรุณาเปลี่ยน!', 'error', '../index.php');
    exit();
} elseif ($mb_pass != $mb_pass2) { //ตรวจรหัสครั้งแรกและครั้งที่สอง
    js_alert('รหัสผ่่านทั้ง 2 ครั้ง ไม่ตรงกัน!', 'error', '../index.php');
    exit();
} else {

    //บันทึกข้อมูลสมาชิก
    $sqlreg = "insert into member_rb(mb_email,mb_pass,mb_type,mb_name,mb_phone)
    values('$mb_email','$mb_pass','$mb_type','$mb_name','$mb_phone')";
    mysqli_query($conn, $sqlreg) or die("sql reg error");

    //ดึง mb_code จากเมลที่ใช้สมัคร
    $sqlmb_code = "select mb_code from member_rb where mb_email='$mb_email' ";
    $result = mysqli_query($conn, $sqlmb_code) or die("sql mb_code error");
    $row = mysqli_fetch_assoc($result);

    //บันทึกพิกัดที่อยู่


    mysqli_close($conn);
    session_start();
    $_SESSION['email'] = $mb_email;
    $_SESSION['pass'] = $mb_pass;
    $_SESSION['name'] = $mb_name;
    $_SESSION['type'] = $mb_type;

    js_alert('สมัครสมาชิกสำเร็จ', 'success', '../index.php');
}



?>