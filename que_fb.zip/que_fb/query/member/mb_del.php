<?php
require("../../config/connect.php");
//member_rb
$mb_code = mysqli_real_escape_string($conn, $_GET["mb_code"]);


if ($count > 0) {
    //ลบที่อยู่ของสมาชิกก่อน
    $sql = "delete from address where mb_code='$mb_code' ";
    mysqli_query($conn, $sql) or die("sql failed to del addr");
}

//ตรวจการมีอยู่ของใบรายการขาย
$sqlcheck = "select ss_code from saleslip where mb_code='$mb_code' ";
$result = mysqli_query($conn, $sqlcheck) or die("sqlcheck code error");
$count = mysqli_num_rows($result);
echo $count;
if ($count > 0) {

    while ($row = mysqli_fetch_assoc($result)) {
        $ss_code = $row['ss_code'];
        //ตรวจการมีรายละเอียดการขาย
        $sqlcheckss = "select s_code from sale where ss_code='$ss_code' ";
        $resultss = mysqli_query($conn, $sqlcheckss) or die("sqlcheck code error");
        $countss = mysqli_num_rows($resultss);

        if ($countss > 0) {
            //ลบรายละเอียดการขายก่อน
            $sql = "delete from sale where ss_code='$ss_code' ";
            mysqli_query($conn, $sql) or die("sql failed to del sale");
        }
    }


    //ลบที่ใบรายการขายของสมาชิก
    $sql = "delete from saleslip where mb_code='$mb_code' ";
    mysqli_query($conn, $sql) or die("sql failed to del saleslip" . mysqli_error($conn));
}

//ลบสมาชิก
$sql = "delete from member_rb where mb_code='$mb_code' ";
mysqli_query($conn, $sql) or die("sql failed to del member");
mysqli_close($conn);

js_alert('ลบสมาชิกสำเร็จ', 'success', '../../admin/?mng=mng_member');
