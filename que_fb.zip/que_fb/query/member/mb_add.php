<?php
require("../../config/connect.php");
//member_rb
$mb_email = mysqli_real_escape_string($conn, $_POST['mb_email']);
$mb_pass = mysqli_real_escape_string($conn, $_POST['mb_pass']);
$mb_type = mysqli_real_escape_string($conn, $_POST['mb_type']);
$mb_name = mysqli_real_escape_string($conn, $_POST['mb_name']);
$mb_phone = mysqli_real_escape_string($conn, $_POST['mb_phone']);



//ตรวจการซ้ำของ email
$sqlcheck = "select mb_email from member_rb where mb_email='$mb_email' ";
$result = mysqli_query($conn, $sqlcheck) or die("sqlcheck email error");
$count = mysqli_num_rows($result);
if ($count > 0) {
    js_alert('Email นี้ถูกใช้ไปแล้ว กรุณาเปลี่ยน!', 'error', '../../admin/?mng=mng_member');
    exit();
} else {

    //บันทึกข้อมูลสมาชิก
    $sqlreg = "insert into member_rb(mb_email,mb_pass,mb_type,mb_name,mb_phone)
    values('$mb_email','$mb_pass','$mb_type','$mb_name','$mb_phone')";
    mysqli_query($conn, $sqlreg) or die("sql reg error");


    mysqli_close($conn);

    js_alert('บันทึกสมาชิกสำเร็จ', 'success', '../../admin/?mng=mng_member');
}



?>