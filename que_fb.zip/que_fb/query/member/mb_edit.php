<?php
require("../../config/connect.php");
//member_rb
$mb_code = mysqli_real_escape_string($conn, $_POST['mb_code']);
$mb_email = mysqli_real_escape_string($conn, $_POST['mb_email']);
$mb_pass = mysqli_real_escape_string($conn, $_POST['mb_pass']);
$mb_type = mysqli_real_escape_string($conn, $_POST['mb_type']);
$mb_name = mysqli_real_escape_string($conn, $_POST['mb_name']);
$mb_phone = mysqli_real_escape_string($conn, $_POST['mb_phone']);

$sql="update member_rb set mb_email='$mb_email',
mb_pass='$mb_pass',
mb_type='$mb_type',
mb_name='$mb_name',
mb_phone='$mb_phone' 
where mb_code='$mb_code' ";
mysqli_query($conn,$sql) or die ("sql failed to update");
mysqli_close($conn);

js_alert('แก้ไขสมาชิกสำเร็จ', 'success', '../../admin/?mng=mng_member');
	
?>