<?php
require("../../config/connect.php");
//member_rb
//$name_field = mysqli_real_escape_string($conn, $_POST['name_field']);
//$status_field = mysqli_real_escape_string($conn, $_POST['status_field']);
$name_field=$_POST['name_field'];

$status_field=$_POST['status_field'];
    //บันทึกข้อมูลสนาม
    $sqlreg = "insert into field(name_field,status_field)
    values('$name_field','$status_field')";
    mysqli_query($conn, $sqlreg) or die("sql reg error");


    mysqli_close($conn);

    js_alert('บันทึกสนามสำเร็จ', 'success', '../../admin/?mng=mng_field');




?>