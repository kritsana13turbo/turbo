<?php
require("../../config/connect.php");
$id_field = mysqli_real_escape_string($conn, $_GET["id_field"]);


//ตรวจการมีรายละเอียดการขาย
//$sqlcheck = "select s_code from sale where m_code='$m_code' ";
//$result = mysqli_query($conn, $sqlcheck) or die("sqlcheck code error");
//$count = mysqli_num_rows($result);/

//if ($count > 0) {
    //ลบรายละเอียดการขายก่อน
//    $sql="delete from sale where m_code='$m_code' ";/
//	mysqli_query($conn,$sql) or die ("sql failed to del sale");
//}

//ลบสนาม
$sql="delete from field where id_field='$id_field' ";
mysqli_query($conn,$sql) or die ("sql failed to del menu");
mysqli_close($conn);



js_alert('ลบข้อมูลสนามสำเร็จ', 'success', '../../admin/?mng=mng_field');
	
?>