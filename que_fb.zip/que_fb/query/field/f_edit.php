<?php
require("../config/connect.php");
//member_rb
$id_filed = mysqli_real_escape_string($conn, $_POST['id_filed']);
$name_filed = mysqli_real_escape_string($conn, $_POST['name_filed']);
$status_field = mysqli_real_escape_string($conn, $_POST['status_field']);

$sql="update field set name_field='$name_field',
status_field='$status_field' 
where id_field='$id_field' ";
mysqli_query($conn,$sql) or die ("sql failed to update");
mysqli_close($conn);

js_alert('แก้ไขสนามสำเร็จ', 'success', '../../admin/?mng=mng_field');
	
?>