<?php
require("../../config/connect.php");

$s_code = mysqli_real_escape_string($conn, $_GET["s_code"]);


//ลบรายละเอียดการขาย
$sql = "delete from sale where s_code='$s_code' ";
mysqli_query($conn, $sql) or die("sql failed to del saleslip");


js_alert('ลบรายละเอียดการขายสำเร็จ', 'success', '../../admin/?mng=mng_sale');
