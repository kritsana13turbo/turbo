<?php
require("../../config/connect.php");

$m_code = mysqli_real_escape_string($conn, $_POST['m_code']);
$s_total = mysqli_real_escape_string($conn, $_POST['s_total']);
$s_price = mysqli_real_escape_string($conn, $_POST['s_price']);
$ss_code = mysqli_real_escape_string($conn, $_POST['ss_code']);



//ตรวจการมีอยู่ใบรายการขาย
$sqlcheck = "select ss_code from saleslip where ss_code='$ss_code' ";
$result = mysqli_query($conn, $sqlcheck) or die("sqlcheck code error");
$count = mysqli_num_rows($result);
if ($count == 0) {
    js_alert('ไม่พบเลขที่ใบรายการขายดังกล่าว!', 'error', '../../admin/?mng=mng_sale');
    exit();
} else {

    //บันทึกรายละเอียดการขาย
    $sqlsale = "insert into sale(s_total,s_price,m_code,ss_code)
    values('$s_total','$s_price','$m_code','$ss_code')";
    mysqli_query($conn, $sqlsale) or die("sql sale error");

    mysqli_close($conn);

    js_alert('บันทึกรายละเอียดการขายสำเร็จ', 'success', '../../admin/?mng=mng_sale');
}
