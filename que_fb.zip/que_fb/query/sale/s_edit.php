<?php
require("../../config/connect.php");

$s_code = mysqli_real_escape_string($conn, $_POST['s_code']);
$s_total = mysqli_real_escape_string($conn, $_POST['s_total']);
$s_price = mysqli_real_escape_string($conn, $_POST['s_price']);
$m_code = mysqli_real_escape_string($conn, $_POST['m_code']);

$sql="update sale set
s_total='$s_total',
s_price='$s_price',
m_code='$m_code' 
where s_code='$s_code' ";

mysqli_query($conn,$sql) or die ("sql failed to update");
mysqli_close($conn);

js_alert('แก้ไขรายละเอียดการขายสำเร็จ', 'success', '../../admin/?mng=mng_sale');
	
?>