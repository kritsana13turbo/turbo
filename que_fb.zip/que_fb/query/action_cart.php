<?php  
 //action.php  
 session_start();   
 if(isset($_POST["product_id"]))  
 {  
      $order_table = '';  
      $message = '';  
      if($_POST["action"] == "add")  
      {  
           if(isset($_SESSION["shopping_cart"]))  
           {  
                $is_available = 0;  
                foreach($_SESSION["shopping_cart"] as $keys => $values)  
                {  
                     if($_SESSION["shopping_cart"][$keys]['product_id'] == $_POST["product_id"])  
                     {  
                          $is_available++;  
                          $_SESSION["shopping_cart"][$keys]['product_quantity'] = $_SESSION["shopping_cart"][$keys]['product_quantity'] + $_POST["product_quantity"];  
                     }  
                }  
                if($is_available < 1)  
                {  
                     $item_array = array(  
                          'product_id'               =>     $_POST["product_id"],  
                          'product_name'               =>     $_POST["product_name"],  
                          'product_price'               =>     $_POST["product_price"],  
                          'product_quantity'          =>     $_POST["product_quantity"]  
                     );  
                     $_SESSION["shopping_cart"][] = $item_array;  
                }  
           }  
           else  
           {  
                $item_array = array(  
                     'product_id'               =>     $_POST["product_id"],  
                     'product_name'               =>     $_POST["product_name"],  
                     'product_price'               =>     $_POST["product_price"],  
                     'product_quantity'          =>     $_POST["product_quantity"]  
                );  
                $_SESSION["shopping_cart"][] = $item_array;  
           }  
      }  
      if($_POST["action"] == "remove")  
      {  
           foreach($_SESSION["shopping_cart"] as $keys => $values)  
           {  
                if($values["product_id"] == $_POST["product_id"])  
                {  
                     unset($_SESSION["shopping_cart"][$keys]);  
                     $message = '<div class="alert alert-dismissible alert-success">
                     <button type="button" class="close" data-dismiss="alert">&times;</button>
                     <strong> สำเร็จ !</strong> ลบรายการเมนูแล้ว
                   </div>';  
                }  
           }  
      }  
      if($_POST["action"] == "quantity_change")  
      {  
           foreach($_SESSION["shopping_cart"] as $keys => $values)  
           {  
                if($_SESSION["shopping_cart"][$keys]['product_id'] == $_POST["product_id"])  
                {  
                     $_SESSION["shopping_cart"][$keys]['product_quantity'] = $_POST["quantity"];  
                }  
           }  
      }  
      $order_table .= '  
           '.$message.'  
           <table class="table table-hover">  
                <tr>  
                     <th width="40%">เมนู</th>  
                     <th width="10%">จำนวน</th>  
                     <th width="20%" style="text-align:right;">ราคา</th>  
                     <th width="20%" style="text-align:right;">รวม</th>  
                     <th width="5%"  style="text-align:center;">ลบ</th>  
                </tr>  
           ';  
      if(!empty($_SESSION["shopping_cart"]))  
      {  
           $total = 0;  
           $num_order = 0;
           foreach($_SESSION["shopping_cart"] as $keys => $values)  
           {  
                
                $order_table .= '  
                     <tr>  
                          <td>'.$values["product_name"].'</td>  
                          <td><input type="text" name="quantity[]" id="quantity'.$values["product_id"].'cart" value="'.$values["product_quantity"].'" class="form-control form-control-sm quantity" data-product_id="'.$values["product_id"].'" /></td>  
                          <td align="right">฿ '.$values["product_price"].'</td>  
                          <td align="right">฿ '.number_format($values["product_quantity"] * $values["product_price"]).'</td>  
                          <td><button name="delete" class="btn btn-danger btn-sm delete" id="'.$values["product_id"].'"><i class="fa fa-times" aria-hidden="true"></i></button></td>  
                     </tr>  
                ';  
                $num_order = $num_order + $values["product_quantity"];
                $total = $total + ($values["product_quantity"] * $values["product_price"]);  
           }  
           $order_table .= '  
                <tr>  
                     <td colspan="3" align="right">ราคารวม</td>  
                     <td align="right">฿ '.number_format($total).'</td>  
                     <td></td>  
                </tr>  
                <tr>  
                     <td colspan="5" align="right">  
                          <form method="post" action="?url=cart_step1">  
                               <input type="submit" name="place_order" class="btn btn-info" value="ชำระเงิน" />  
                          </form>  
                     </td>  
                </tr>  
           ';  
      }  else {
          $num_order = 0;
      }
      $order_table .= '</table>';  
      $_SESSION["num_order"] = $num_order ;
      $output = array(  
           'order_table'     =>     $order_table,  
           'cart_item'       =>     $num_order  
      );  
      echo json_encode($output);  
 }  
 ?>