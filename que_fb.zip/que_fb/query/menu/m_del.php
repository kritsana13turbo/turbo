<?php
require("../../config/connect.php");
$m_code = mysqli_real_escape_string($conn, $_GET["m_code"]);
$m_pic = mysqli_real_escape_string($conn, $_GET["m_pic"]);

//ตรวจการมีรายละเอียดการขาย
$sqlcheck = "select s_code from sale where m_code='$m_code' ";
$result = mysqli_query($conn, $sqlcheck) or die("sqlcheck code error");
$count = mysqli_num_rows($result);

if ($count > 0) {
    //ลบรายละเอียดการขายก่อน
    $sql="delete from sale where m_code='$m_code' ";
	mysqli_query($conn,$sql) or die ("sql failed to del sale");
}

//ลบเมนู
$sql="delete from menu where m_code='$m_code' ";
mysqli_query($conn,$sql) or die ("sql failed to del menu");
mysqli_close($conn);

//โฟลเดอร์ที่เก็บไฟล์
$path="../../img/menu/";
//ลบไฟล์
unlink($path.$m_pic);


js_alert('ลบเมนูและรายละเอียดการขายที่เกี่ยวข้องสำเร็จ', 'success', '../../admin/?mng=mng_menu');
	
?>