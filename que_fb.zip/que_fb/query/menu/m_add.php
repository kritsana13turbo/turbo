<?php
require("../../config/connect.php");

//Set ว/ด/ป เวลา ให้เป็นของประเทศไทย
date_default_timezone_set('Asia/Bangkok');
	//สร้างตัวแปรวันที่เพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลด
	$date1 = date("Ymd_His");
	//สร้างตัวแปรสุ่มตัวเลขเพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลดไม่ให้ชื่อไฟล์ซ้ำกัน
	$numrand = (mt_rand());
    
//รับค่าไฟล์จากฟอร์ม
$m_name = mysqli_real_escape_string($conn, $_POST['m_name']);
$m_pic =(isset($_POST['m_pic']) ? $_POST['m_pic'] :'');
$m_detail = mysqli_real_escape_string($conn, $_POST['m_detail']);
$m_price = mysqli_real_escape_string($conn, $_POST['m_price']);


	$upload=$_FILES['m_pic'];
	if($upload <> '') {
 
	//โฟลเดอร์ที่เก็บไฟล์
	$path="../../img/menu/";
	//ตัวขื่อกับนามสกุลภาพออกจากกัน
	$type = strrchr($_FILES['m_pic']['name'],".");
	//ตั้งชื่อไฟล์ใหม่เป็น สุ่มตัวเลข+วันที่
	$newname ='m_pic'.$numrand.$date1.$type;
    $path_copy=$path.$newname;
	
    
	//คัดลอกไฟล์ไปยังโฟลเดอร์
	move_uploaded_file($_FILES['m_pic']['tmp_name'],$path_copy);

	}

    //บันทึกข้อมูลเมนู
    $sqlreg = "insert into menu(m_name,m_pic,m_detail,m_price)
    values('$m_name','$newname','$m_detail','$m_price')";
    mysqli_query($conn, $sqlreg) or die("sql add error");


    mysqli_close($conn);

    js_alert('บันทึกเมนูสำเร็จ', 'success', '../../admin/?mng=mng_menu');


?>

