<?php
require("../../config/connect.php");

//Set ว/ด/ป เวลา ให้เป็นของประเทศไทย
date_default_timezone_set('Asia/Bangkok');
	//สร้างตัวแปรวันที่เพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลด
	$date1 = date("Ymd_His");
	//สร้างตัวแปรสุ่มตัวเลขเพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลดไม่ให้ชื่อไฟล์ซ้ำกัน
	$numrand = (mt_rand());
    
//รับค่าไฟล์จากฟอร์ม
$m_code = mysqli_real_escape_string($conn, $_POST['m_code']);
$m_name = mysqli_real_escape_string($conn, $_POST['m_name']);
$m_pic = mysqli_real_escape_string($conn, $_POST['m_pic']);
$m_pic_edit =(isset($_POST['m_pic_edit']) ? $_POST['m_pic_edit'] :'');
$m_detail = mysqli_real_escape_string($conn, $_POST['m_detail']);
$m_price = mysqli_real_escape_string($conn, $_POST['m_price']);

    //error 4 คือค่าที่แสดงเมื่อไม่ได้แนบไฟลมา error 0 คืออัพโหลดปกติ
	if($_FILES['m_pic_edit']['error'] == 0) {
 
	//โฟลเดอร์ที่เก็บไฟล์
	$path="../../img/menu/";
	//ตัวขื่อกับนามสกุลภาพออกจากกัน
	$type = strrchr($_FILES['m_pic_edit']['name'],".");
	//ตั้งชื่อไฟล์ใหม่เป็น สุ่มตัวเลข+วันที่
	$newname ='m_pic_edit'.$numrand.$date1.$type;
    $path_copy=$path.$newname;
	
	//คัดลอกไฟล์ไปยังโฟลเดอร์
    move_uploaded_file($_FILES['m_pic_edit']['tmp_name'],$path_copy);
    
    //ลบไฟล์เก่า
    unlink($path.$m_pic);

	} else {
        $newname = $m_pic;
    }

//echo $newname;

$sql="update menu set m_name='$m_name',
m_pic='$newname',
m_detail='$m_detail',
m_price='$m_price' 
where m_code='$m_code' ";
mysqli_query($conn,$sql) or die ("sql failed to update");
mysqli_close($conn);

js_alert('แก้ไขเมนูสำเร็จ', 'success', '../../admin/?mng=mng_menu');
	
?>