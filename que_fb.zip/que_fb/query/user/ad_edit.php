<?php
require("../../config/connect.php");
//member_rb
$ad_code = mysqli_real_escape_string($conn, $_POST['ad_code']);
$ad_lat = mysqli_real_escape_string($conn, $_POST['ad_lat']);
$ad_lon = mysqli_real_escape_string($conn, $_POST['ad_lon']);
$ad_name = mysqli_real_escape_string($conn, $_POST['ad_name']);
$ad_detail = mysqli_real_escape_string($conn, $_POST['ad_detail']);

$sql="update address set ad_lat='$ad_lat',
ad_lon='$ad_lon',
ad_name='$ad_name',
ad_detail='$ad_detail' 
where ad_code='$ad_code' ";
mysqli_query($conn,$sql) or die ("sql failed to update");
mysqli_close($conn);

js_alert('แก้ไขที่อยู่สำเร็จ', 'success', '../../?url=home');
	
?>