<?php
require("../../config/connect.php");
$ss_code = mysqli_real_escape_string($conn, $_GET["ss_code"]);


//ตรวจการมีรายละเอียดการขาย
$sqlcheck = "select ss_status from saleslip where ss_code='$ss_code' ";
$result = mysqli_query($conn, $sqlcheck) or die("sqlcheck code error");
$row = mysqli_fetch_assoc($result);

switch ($row['ss_status']) {
    case "3":
        js_alert('คำสั่งซื้อนี้ถูกยกเลิกอยู่แล้ว', 'warning', '../../?url=saleslip_member');
    break;
    case "2":
        js_alert('ไม่สามารถยกเลิกได้เนื่องจากอนุมัติแล้ว', 'error', '../../?url=saleslip_member');
    break;
    case "1":
        $sql="update saleslip set ss_status=3 where ss_code ='$ss_code'";
        mysqli_query($conn,$sql) or die ("sql failed to update");
        js_alert('ยกเลิกคำสั่งซื้อสำเร็จ', 'success', '../../?url=saleslip_member'); 
    break;
}

mysqli_close($conn);

?>