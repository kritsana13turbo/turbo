<?php
require("../../config/connect.php");

if(isset($_POST['id']))
{
    $ss_code = $_POST['id'];

    $sql= "select * from sale 
    INNER JOIN menu ON sale.m_code = menu.m_code
    where ss_code='$ss_code'";
    $result = mysqli_query($conn, $sql) or die("sql code error");
}
    //echo json_encode($result);
?>
<table border="0" class="table table-striped table-bordered" id="mng_menu" align="center">
    <thead>
        <tr class="table-light">
            <th>ชื่อเมนู</th>
            <th>รูป</th>
            <th>ราคา(ต่อชิ้น)</th>
            <th>จำนวน</th>
            <th>ราคารวม</th>
            
        </tr>
    </thead>
    <?php
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['m_name']; ?></td>
                <td><img src="<?php echo 'img/menu/'.$row['m_pic']; ?>"   class="rounded img-fluid"></td>
                <td><?php echo $row['m_price']; ?></td>
                <td><?php echo $row['s_total']; ?></td>
                <td><?php echo $row['s_price']; ?></td>
        <?php
        }
            ?>

            </tr>
</table>
<?php
} else {
    echo "0 results";
}
    mysqli_close($conn);
?>