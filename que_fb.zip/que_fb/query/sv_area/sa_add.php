<?php
require("../../config/connect.php");

$sa_name = mysqli_real_escape_string($conn, $_POST['sa_name']);
$sa_cost = mysqli_real_escape_string($conn, $_POST['sa_cost']);


$sqladd = "insert into servicearea(sa_name,sa_cost)
values('$sa_name','$sa_cost')";
mysqli_query($conn, $sqladd) or die("sql add error");


mysqli_close($conn);

js_alert('บันทึกพื้นที่ให้บริการสำเร็จ', 'success', '../../admin/?mng=mng_sv_area');
