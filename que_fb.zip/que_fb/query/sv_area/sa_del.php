<?php
require("../../config/connect.php");

$sa_code = mysqli_real_escape_string($conn, $_GET["sa_code"]);

//ตรวจการมีอยู่ของใบรายการขาย
$sqlcheck = "select ss_code from saleslip where sa_code='$sa_code' ";
$result = mysqli_query($conn, $sqlcheck) or die("sqlcheck code error");
$count = mysqli_num_rows($result);

if ($count > 0) {
    //เรียกใบรายการขายที่เกี่ยวข้องทั้งหมด
    while ($row = mysqli_fetch_assoc($result)) {

        //ลบรายละเอียดการขายก่อน
        $sql="delete from sale where ss_code='".$row['ss_code']."' ";
        mysqli_query($conn,$sql) or die ("sql failed to del sale");

    }

    //ลบใบรายการขาย
    $sql="delete from saleslip where sa_code='$sa_code' ";
    mysqli_query($conn,$sql) or die ("sql failed to del saleslip");
}

//ลบพื้นที่
$sql="delete from servicearea where sa_code='$sa_code' ";
mysqli_query($conn,$sql) or die ("sql failed to del servicearea");
mysqli_close($conn);

js_alert('ลบพื้นที่,ใบรายการขาย และ รายละเอียดที่เกี่ยวข้องสำเร็จ', 'success', '../../admin/?mng=mng_sv_area');