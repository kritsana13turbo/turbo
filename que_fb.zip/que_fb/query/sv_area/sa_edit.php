<?php
require("../../config/connect.php");

$sa_code = mysqli_real_escape_string($conn, $_POST['sa_code']);
$sa_name = mysqli_real_escape_string($conn, $_POST['sa_name']);
$sa_cost = mysqli_real_escape_string($conn, $_POST['sa_cost']);

$sql="update servicearea set
sa_name='$sa_name',
sa_cost='$sa_cost' 
where sa_code='$sa_code' ";

mysqli_query($conn,$sql) or die ("sql failed to update");
mysqli_close($conn);

js_alert('แก้ไขพื้นที่ให้บริการสำเร็จ', 'success', '../../admin/?mng=mng_sv_area');
	
?>