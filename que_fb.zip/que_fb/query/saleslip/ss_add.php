<?php
require("../../config/connect.php");

//Set ว/ด/ป เวลา ให้เป็นของประเทศไทย
date_default_timezone_set('Asia/Bangkok');
	//สร้างตัวแปรวันที่เพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลด
	$date1 = date("Ymd_His");
	//สร้างตัวแปรสุ่มตัวเลขเพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลดไม่ให้ชื่อไฟล์ซ้ำกัน
	$numrand = (mt_rand());
    
//รับค่าไฟล์จากฟอร์ม
$ss_time = mysqli_real_escape_string($conn, $_POST['ss_time']);
$ss_totalprice = mysqli_real_escape_string($conn, $_POST['ss_totalprice']);
$ss_discount = mysqli_real_escape_string($conn, $_POST['ss_discount']);
$ss_netprice = mysqli_real_escape_string($conn, $_POST['ss_netprice']);
$pm_method = mysqli_real_escape_string($conn, $_POST['pm_method']);
$pm_pic =(isset($_POST['pm_pic']) ? $_POST['pm_pic'] :'');
$ss_status = mysqli_real_escape_string($conn, $_POST['ss_status']);
$pm_status = mysqli_real_escape_string($conn, $_POST['pm_status']);
$ss_note = mysqli_real_escape_string($conn, $_POST['ss_note']);
$dt_code = mysqli_real_escape_string($conn, $_POST['dt_code']);
$sa_code = mysqli_real_escape_string($conn, $_POST['sa_code']);
$mb_code = mysqli_real_escape_string($conn, $_POST['mb_code']);


	//error 4 คือค่าที่แสดงเมื่อไม่ได้แนบไฟลมา error 0 คืออัพโหลดปกติ
	if($_FILES['pm_pic']['error'] == 0) {
 
		//โฟลเดอร์ที่เก็บไฟล์
		$path="../../img/slip/";
		//ตัวขื่อกับนามสกุลภาพออกจากกัน
		$type = strrchr($_FILES['pm_pic']['name'],".");
		//ตั้งชื่อไฟล์ใหม่เป็น สุ่มตัวเลข+วันที่
		$newname ='pm_pic'.$numrand.$date1.$type;
		$path_copy=$path.$newname;
		
		//คัดลอกไฟล์ไปยังโฟลเดอร์
		move_uploaded_file($_FILES['pm_pic']['tmp_name'],$path_copy);
		
	
		} else {
			$newname = $pm_pic;
		}

//ตรวจการมีอยู่ของสมาชิก
$sqlcheck = "select mb_code from member_rb where mb_code='$mb_code' ";
$result = mysqli_query($conn, $sqlcheck) or die("sqlcheck code error");
$count = mysqli_num_rows($result);
if ($count == 0) {
    js_alert('ไม่พบรหัสสมาชิกดังกล่าว!', 'error', '../../admin/?mng=mng_saleslip');
    exit();
} elseif ($pm_method==2 and $newname=='') {
	js_alert('ชำระเงินผ่านช่องทางการโอนธนาคาร กรุณาแนบหลักฐาน!', 'error', '../../admin/?mng=mng_saleslip');
    exit();
} else {

    //บันทึกข้อมูลเมนู
	$sql = "insert into saleslip
	(ss_time,
	ss_totalprice,
	ss_discount,
	ss_netprice,
	pm_method,
	pm_pic,
	ss_status,
	pm_status,
	ss_note,
	dt_code,
	sa_code,
	mb_code)
	values
	('$ss_time',
	'$ss_totalprice',
	'$ss_discount',
	'$ss_netprice',
	'$pm_method',
	'$newname',
	'$ss_status',
	'$pm_status',
	'$ss_note',
	'$dt_code',
	'$sa_code',
	'$mb_code')";
    mysqli_query($conn, $sql) or die("sql add error");


    mysqli_close($conn);

    js_alert('บันทึกใบรายการขายสำเร็จ', 'success', '../../admin/?mng=mng_saleslip');
}
