<?php
require("../../config/connect.php");

//Set ว/ด/ป เวลา ให้เป็นของประเทศไทย
date_default_timezone_set('Asia/Bangkok');
	//สร้างตัวแปรวันที่เพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลด
	$date1 = date("Ymd_His");
	//สร้างตัวแปรสุ่มตัวเลขเพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลดไม่ให้ชื่อไฟล์ซ้ำกัน
	$numrand = (mt_rand());
    
//รับค่าไฟล์จากฟอร์ม
$ss_code = mysqli_real_escape_string($conn, $_POST['ss_code_edit']);
$ss_time = mysqli_real_escape_string($conn, $_POST['ss_time_edit']);
$ss_totalprice = mysqli_real_escape_string($conn, $_POST['ss_totalprice_edit']);
$ss_discount = mysqli_real_escape_string($conn, $_POST['ss_discount_edit']);
$ss_netprice = mysqli_real_escape_string($conn, $_POST['ss_netprice_edit']);
$pm_method = mysqli_real_escape_string($conn, $_POST['pm_method_edit']);
$pm_pic = mysqli_real_escape_string($conn, $_POST['pm_pic_edit']);
$pm_pic_edit_new =(isset($_POST['pm_pic_edit_new']) ? $_POST['pm_pic_edit_new'] :'');
$ss_status = mysqli_real_escape_string($conn, $_POST['ss_status_edit']);
$ss_note = mysqli_real_escape_string($conn, $_POST['ss_note_edit']);
$pm_status = mysqli_real_escape_string($conn, $_POST['pm_status_edit']);
$dt_code = mysqli_real_escape_string($conn, $_POST['dt_code_edit']);
$sa_code = mysqli_real_escape_string($conn, $_POST['sa_code_edit']);
$mb_code = mysqli_real_escape_string($conn, $_POST['mb_code_edit']);

    //error 4 คือค่าที่แสดงเมื่อไม่ได้แนบไฟลมา error 0 คืออัพโหลดปกติ
	if($_FILES['pm_pic_edit_new']['error'] == 0) {
 
	//โฟลเดอร์ที่เก็บไฟล์
	$path="../../img/slip/";
	//ตัวขื่อกับนามสกุลภาพออกจากกัน
	$type = strrchr($_FILES['pm_pic_edit_new']['name'],".");
	//ตั้งชื่อไฟล์ใหม่เป็น สุ่มตัวเลข+วันที่
	$newname ='pm_pic'.$numrand.$date1.$type;
    $path_copy=$path.$newname;
	
	//คัดลอกไฟล์ไปยังโฟลเดอร์
    move_uploaded_file($_FILES['pm_pic_edit_new']['tmp_name'],$path_copy);
    
    //ลบไฟล์เก่า
    unlink($path.$pm_pic);

	} else {
        $newname = $pm_pic;
    }


$sql="update saleslip set 
ss_time='$ss_time',
ss_totalprice='$ss_totalprice',
ss_discount='$ss_discount',
ss_netprice='$ss_netprice',
pm_method='$pm_method',
pm_pic='$newname',
ss_status='$ss_status',
pm_status='$pm_status' ,
ss_note='$ss_note' ,
dt_code='$dt_code' ,
sa_code='$sa_code' ,
mb_code='$mb_code' 
where ss_code ='$ss_code ' ";
mysqli_query($conn,$sql) or die ("sql failed to update");
mysqli_close($conn);

js_alert('แก้ไขใบรายการขายสำเร็จ', 'success', '../../admin/?mng=mng_saleslip');
	
?>