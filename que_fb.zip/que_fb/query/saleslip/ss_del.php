<?php
require("../../config/connect.php");
$ss_code = mysqli_real_escape_string($conn, $_GET["ss_code"]);
$pm_pic = mysqli_real_escape_string($conn, $_GET["pm_pic"]);

//ตรวจการมีรายละเอียดการขาย
$sqlcheck = "select s_code from sale where ss_code='$ss_code' ";
$result = mysqli_query($conn, $sqlcheck) or die("sqlcheck code error");
$count = mysqli_num_rows($result);

if ($count > 0) {
    //ลบรายละเอียดการขายก่อน
    $sql="delete from sale where ss_code='$ss_code' ";
	mysqli_query($conn,$sql) or die ("sql failed to del sale");
}

//ลบใบรายการขาย
$sql="delete from saleslip where ss_code='$ss_code' ";
mysqli_query($conn,$sql) or die ("sql failed to del saleslip");
mysqli_close($conn);

//โฟลเดอร์ที่เก็บไฟล์
$path="../../img/slip/";
//ลบไฟล์
unlink($path.$pm_pic);


js_alert('ลบใบรายการขายและรายละเอียดการขายที่เกี่ยวข้องสำเร็จ', 'success', '../../admin/?mng=mng_saleslip');
	
?>