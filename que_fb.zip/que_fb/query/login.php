<?PHP
session_start();
header('Content-Type: text/html; charset=utf-8');

require("../config/connect.php");


$email = mysqli_real_escape_string($conn,$_POST['mb_email']);
$pass = mysqli_real_escape_string($conn,$_POST['mb_pass']);


$sqlcheck="select * from member_rb where mb_email='$email' ";
$result=mysqli_query($conn,$sqlcheck) or die("sqlcheckError!".mysqli_error($conn));
$count=mysqli_num_rows($result);
$row=mysqli_fetch_assoc($result);
if($count==0)
{
    js_alert('Email ไม่ถูกต้อง!','error','../index.php');
    exit();
}
if($row['mb_pass'] !== $pass){
    js_alert('Password ไม่ถูกต้อง!','error','../index.php');
    exit();
}


$_SESSION['email'] = $email;
$_SESSION['pass'] = $pass;
$_SESSION['name'] = $row['mb_name'];
$_SESSION['type'] = $row['mb_type'];
$_SESSION['mb_code'] = $row['mb_code'];


switch ($row['mb_type']) {
    case "3":
        js_alert('เข้าสู่ระบบผู้ดูแลสำเร็จ','success','../admin/');
      break;
    case "1":
        js_alert('เข้าสู่ระบบสำเร็จ','success','../');
      break;
    default:
        js_alert('เข้าสู่ระบบสำเร็จ','success','../');
  }

mysqli_close($conn);

?>
