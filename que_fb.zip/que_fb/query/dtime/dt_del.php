<?php
require("../../config/connect.php");

$dt_code = mysqli_real_escape_string($conn, $_GET["dt_code"]);

//ตรวจการมีอยู่ของใบรายการขาย
$sqlcheck = "select ss_code from saleslip where dt_code='$dt_code' ";
$result = mysqli_query($conn, $sqlcheck) or die("sqlcheck code error");
$count = mysqli_num_rows($result);

if ($count > 0) {
    //เรียกใบรายการขายที่เกี่ยวข้องทั้งหมด
    while ($row = mysqli_fetch_assoc($result)) {

        //ลบรายละเอียดการขายก่อน
        $sql="delete from sale where ss_code='".$row['ss_code']."' ";
        mysqli_query($conn,$sql) or die ("sql failed to del sale");

    }

    //ลบใบรายการขาย
    $sql="delete from saleslip where dt_code='$dt_code' ";
    mysqli_query($conn,$sql) or die ("sql failed to del saleslip");
}

//ลบเวลาจัดส่ง
$sql="delete from deliverytime where dt_code='$dt_code' ";
mysqli_query($conn,$sql) or die ("sql failed to del deliverytime");
mysqli_close($conn);

js_alert('ลบเวลาจัดส่ง,ใบรายการขาย และ รายละเอียดที่เกี่ยวข้องสำเร็จ', 'success', '../../admin/?mng=mng_dtime');