<?php
require("../../config/connect.php");

$dt_name = mysqli_real_escape_string($conn, $_POST['dt_name']);
$dt_time = mysqli_real_escape_string($conn, $_POST['dt_time']);


$sqladd = "insert into deliverytime(dt_name,dt_time)
values('$dt_name','$dt_time')";
mysqli_query($conn, $sqladd) or die("sql add error");


mysqli_close($conn);

js_alert('บันทึกเวลาจัดส่งสำเร็จ', 'success', '../../admin/?mng=mng_dtime');
