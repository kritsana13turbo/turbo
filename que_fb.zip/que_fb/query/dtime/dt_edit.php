<?php
require("../../config/connect.php");

$dt_code = mysqli_real_escape_string($conn, $_POST['dt_code']);
$dt_name = mysqli_real_escape_string($conn, $_POST['dt_name']);
$dt_time = mysqli_real_escape_string($conn, $_POST['dt_time']);

$sql="update deliverytime set
dt_name='$dt_name',
dt_time='$dt_time' 
where dt_code='$dt_code' ";

mysqli_query($conn,$sql) or die ("sql failed to update");
mysqli_close($conn);

js_alert('แก้ไขเวลาจัดส่งสำเร็จ', 'success', '../../admin/?mng=mng_dtime');
	
?>