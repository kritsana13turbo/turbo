<?php include 'config/setting.php';
require 'session/ss_index.php'; ?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.4.1/litera/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- data table -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
    <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

    <!-- Icon -->
    <link rel="icon" href="<?php echo $icon; ?>" type="image/x-icon">

    <title><?php echo $title_index; ?></title>
</head>

<body>
    <?php
    require("config/connect.php");
    include 'modal/md_login.php';
    include 'modal/md_reg.php';
    include 'modal/md_cart.php';

    if (isset($_SESSION["mb_code"])) {
        $querymb = "SELECT * FROM address INNER JOIN member_rb ON address.mb_code = member_rb.mb_code WHERE member_rb.mb_code='$mb_code'" or die("Error user_addr :" . mysqli_error($conn));
        $resultmb = mysqli_query($conn, $querymb);
        $rowmb = mysqli_fetch_assoc($resultmb);
    }

    $querym = "SELECT * FROM menu ORDER BY m_code ASC" or die("Error user_menu :");
    $resultm = mysqli_query($conn, $querym);

    $querypro = "SELECT * FROM promotion" or die("Error user_menu :");
    $resultpro = mysqli_query($conn, $querypro);
    $rowp = mysqli_fetch_assoc($resultpro)

    ?>
    <div class="container">
        <?php if (!isset($_SESSION["email"]) && !isset($_SESSION["pass"])) {
            require 'menu/mn_index.php';
            include 'pages/img_slide.php'; ?>
            <br>
            <div class="alert alert-dismissible alert-success">
                <h4 class="alert-heading"><i class="fa fa-bullhorn"></i> โปรโมชัน !</h4>
                <p class="mb-0">
                    <?php
                    //$start_date = $rowp['p_startdate'];
                    //$end_date = $rowp['p_enddate'];
                    //$date_from_user = date("Y-m-d");

                    //$promotion = check_in_range($start_date, $end_date, $date_from_user);

                    //เช็คว่าเปิดใช้งานโปรโมชั่น และตรงกับวันที่ปัจจุบันหรือไม่
                    if (($rowp['p_status'] == 1) and $promotion) {
                        echo $rowp['p_name'];
                    } else {
                        echo "วันนี้ทางร้านไม่มีโปรโมชันครับ";
                    }
                    ?>
                </p>
            </div>
            <div class="jumbotron">
                <div class="row mt-2 pb-3">
                    <?php
                    if (mysqli_num_rows($resultm) > 0) {
                        while ($rowm = mysqli_fetch_assoc($resultm)) { ?>
                            <div class="col-lg-3">
                                <div class="card border-success mb-3">
                                    <div class="card-header"><?php echo $rowm['m_name']; ?></div>
                                    <img src="img/menu/<?php echo $rowm['m_pic']; ?>" class="img-fluid">
                                    <div class="card-body">
                                        <h4 class="card-title"><?php echo '฿' . number_format($rowm['m_price']); ?></h4>
                                        <p class="card-text"><?php echo $rowm['m_detail']; ?></p>
                                        <a class="btn btn-success btn-block text-white" data-toggle="modal" data-target="#md_login">
                                            <i class="fa fa-cart-arrow-down" aria-hidden="true"></i>
                                            เพิ่มลงตะกร้้า
                                        </a>
                                    </div>
                                </div>
                            </div>
                    <?php
                        }
                    } else {
                        echo "ไม่พบเมนู";
                    }
                    mysqli_close($conn);
                    ?>
                </div>
            </div>

        <?php
        } else {

            if (isset($_GET['url'])) {
                if (file_exists("pages/" . trim($_GET['url']) . ".php")) {
                    require_once "pages/" . trim($_GET['url']) . ".php";
                } else {
                    require_once "pages/home.php";
                }
            } else {
                require_once "pages/home.php";
            }
        }
        ?>

    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <!-- ใช้ 3.5.1 ข้างบนแทนแล้ว -->
    <!--<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
    </script>
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=<?php echo $gg_api_key; ?>"></script>
    </script>
    <?php
    if (!isset($_SESSION["email"]) && !isset($_SESSION["pass"])) {
        require 'script/ggmap_script.php';
    } else {
        require 'script/ggmap_script_user.php';
    }
    include 'script/cart_script.php';

    function check_in_range($start_date, $end_date, $date_from_user)
    {
        // Convert to timestamp
        //$start_ts = strtotime($start_date);
        //$end_ts = strtotime($end_date);
        //$user_ts = strtotime($date_from_user);

        // เช็ควันที่ลูกค้าว่าอยู่ระหว่างโปรโมชั่นหรือไม่
        //return (($user_ts >= $start_ts) && ($user_ts <= $end_ts));
    }
    ?>
</body>

</html>