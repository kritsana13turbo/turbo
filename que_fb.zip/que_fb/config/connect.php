<?php
$conn = mysqli_connect("localhost","root","12345678","teeyai");

/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

function js_alert($message,$type='info',$redirect='./'){
    echo '
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <body>
    <script>
        swal("", "'.$message.'", "'.$type.'").then(function(){
            window.location="'.$redirect.'";
        });
    </script>
    </body>
    ';
}

?>