<?php
$logo_name = "TEEYAI"; //ชื่อร้าน
$title_index = "TEEYAI"; //ชื่อ title หน้าหลัก สำหรับผู้ใช้ทั่วไป และ สมาชิก
$title_admin = "ระบบจัดการข้อมูล สำหรับ Admin"; //ชื่อ title หน้าระบบจัดการข้อมูล สำหรับแอดมิน
$icon = "img/icon/teeyai.ico"; // ที่จัดเก็บไฟล icon

//รูปภาพสไลด์โชว์ (แนะนำขนาด 1420px*600px) แต่ละรูปต้องขนาดเท่ากันเพื่อความสวยงามในการสไลด์
$img_slide_1 = "img/slide/img_sl1.jpg";
$img_slide_2 = "img/slide/img_sl2.jpg";
$img_slide_3 = "img/slide/img_sl3.jpg";

//ธนาคาร
$banklogo = "img/icon/SCB.png"; //แนะนำขนาด 40*40 px
$bankname = "ไทยพาณิชย์";
$banknumber = "1234567890";
$bank_adminname = "กฤษณ สุวิมล";

$gg_api_key = "AIzaSyB2s8eWt3MG7O2CH9eYek3LA64QzW_ymNo"; //account flukeicanfly3 free $300 in 12 month
?>