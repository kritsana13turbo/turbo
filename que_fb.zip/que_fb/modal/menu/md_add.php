<!-- The Modal -->
<div class="row">

    <div class="modal" id="md_add" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title mx-auto">เพิ่มเมนู</h4>
                    <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->

                </div>
                <form class="form-group" action="../query/menu/m_add.php" method="post" enctype=multipart/form-data>
                    <!-- Modal body -->
                    <div class="modal-body ">
                        <label><i class="fa fa-address-book"></i> &nbsp;ชื่อเมนู</label>
                        <input class="form-control" type="text" name="m_name" placeholder="กรอกชื่อเมนู" required>
                        <label><i class="fa fa-file-image-o"></i> &nbsp;รูปภาพ</label>
                        <input type="file" class="form-control-file" name="m_pic" aria-describedby="fileHelp" required>
                        <small id="fileHelp" class="form-text text-warning">*แนะนำให้ใช้รูปที่มีขนาด 262x201</small>
                        <label><i class="fa fa-file-text-o"></i> &nbsp;รายละเอียดเมนู</label>
                        <textarea class="form-control" name="m_detail" placeholder="กรอกรายละเอียดเกี่ยวกับเมนู" rows="2" required></textarea>
                        <label><i class="fa fa-usd"></i> &nbsp;ราคา</label>
                        <input type="text" class="form-control"  name="m_price" autocomplete="off" placeholder="กรอกราคา" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" required>
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success mx-auto">บันทึก</button>
                        <button type="button" class="btn btn-danger mx-auto" data-dismiss="modal">ปิด</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>