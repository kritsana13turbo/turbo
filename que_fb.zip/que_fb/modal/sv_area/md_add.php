<!-- The Modal -->
<div class="row">

    <div class="modal" id="md_add" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title mx-auto">เพิ่มพื้นที่ให้บริการ</h4>
                    <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->

                </div>
                <form class="form-group" action="../query/sv_area/sa_add.php" method="post">
                    <!-- Modal body -->
                    <div class="modal-body ">
                        <label><i class="fa fa-address-book"></i> &nbsp;ชื่อพื้นที่ให้บริการ</label>
                        <input class="form-control" type="text" name="sa_name" placeholder="กรอกชื่อพื้นที่" required>
                        <label><i class="fa fa-usd"></i> &nbsp;ค่าบริการ</label>
                        <input type="text" class="form-control"  name="sa_cost" autocomplete="off" placeholder="กรอกค่าบริการ" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" required>
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success mx-auto">บันทึก</button>
                        <button type="button" class="btn btn-danger mx-auto" data-dismiss="modal">ปิด</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>