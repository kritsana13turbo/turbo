<!-- The Modal -->
<div class="row">

    <div class="modal" id="md_edit" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title mx-auto">แก้ไขข้อมูลพื้นที่ให้บริการ</h4>
                    <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->

                </div>
                <form class="form-group" action="../query/sv_area/sa_edit.php" method="post">
                    <!-- Modal body -->
                    <div class="modal-body ">
                        <label><i class="fa fa-id-card"></i> &nbsp; รหัสพื้นที่ให้บริการ</label>
                        <input class="form-control" type="text" name="sa_code" id="sa_code" readonly required>
                        <label><i class="fa fa-address-book"></i> &nbsp;ชื่อพื้นที่ให้บริการ</label>
                        <input class="form-control" type="text" name="sa_name" id="sa_name"required>
                        <label><i class="fa fa-usd"></i> &nbsp;ค่าบริการ</label>
                        <input type="text" class="form-control" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" name="sa_cost" id="sa_cost" autocomplete="off" required>
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success mx-auto">บันทึก</button>
                        <button type="button" class="btn btn-danger mx-auto" data-dismiss="modal">ปิด</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>