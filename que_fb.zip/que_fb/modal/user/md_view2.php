<!-- The Modal -->
<div class="row">

    <div class="modal" id="md_view2" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title mx-auto">รายการเมนูที่ซื้อ</h4>
                    <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->

                </div>
                <div class="sale_table"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger mx-left" data-dismiss="modal">ปิด</button>
                </div>
            </div>
        </div>
    </div>
</div>