<!-- The Modal -->
<div class="row">

    <div class="modal" id="md_edit" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title mx-auto">แก้ไขข้อมูลสนาม</h4>
                    <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->

                </div>
                <form class="form-group" action="../query/field/f_edit.php" method="post">
                    <!-- Modal body -->
                    <div class="modal-body ">
                        <label><i class="fa fa-id-card"></i> &nbsp; รหัสสนาม</label>
                        <input class="form-control" type="text" name="id_field" id="id_field" readonly required>
                        <label><i class="fa fa-envelope"></i> &nbsp;ชื่อสนาม</label>
                        <input class="form-control" type="text" name="name_field" id="name_field" required>
                        <label><i class="fa fa-users"></i> &nbsp;สถานะสนาม</label>
                        <select class="form-control" name="status_field" id="status_field">
                            <option value="ใช้งาน">ใช้งาน</option>
                            <option value="ปรับปรุง">ปร้บปรุง</option>
                        </select>
                       
                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success mx-auto">บันทึก</button>
                        <button type="button" class="btn btn-danger mx-auto" data-dismiss="modal">ปิด</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>