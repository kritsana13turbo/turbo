<!-- The Modal -->
<div class="row">

    <div class="modal" id="md_add" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title mx-auto">เพิ่มรายละเอียดการขาย</h4>
                    <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->

                </div>
                <form class="form-group" action="../query/sale/s_add.php" method="post">
                    <!-- Modal body -->
                    <div class="modal-body ">
                    <label><i class="fa fa-truck"></i> &nbsp;เมนู</label>
                        <select class="form-control" name="m_code" required>
                            <option value="">----เลือกเมนู----</option>
                            <?php
                            $sql = "select * from menu";
                            $rs = mysqli_query($conn, $sql) or die("sql menu");
                            while ($row = mysqli_fetch_assoc($rs)) {
                                echo "<option value=" . $row['m_code'] . ">" . $row["m_name"] . "</option>";
                            }
                            ?>
                        </select>
                        <label><i class="fa fa-random"></i> &nbsp;จำนวน</label>
                        <input class="form-control" type="text" name="s_total" placeholder="กรอกจำนวน" required>
                        <label><i class="fa fa-usd"></i> &nbsp;ราคารวม</label>
                        <input type="text" class="form-control"  name="s_price" autocomplete="off" placeholder="กรอกราคารวม" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" required>
                        <label><i class="fa fa-id-card"></i> &nbsp; เลขที่ใบรายการขาย</label>
                        <input class="form-control" type="text" name="ss_code" required>
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success mx-auto">บันทึก</button>
                        <button type="button" class="btn btn-danger mx-auto" data-dismiss="modal">ปิด</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>