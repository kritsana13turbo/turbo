<!-- The Modal -->
<div class="row">

    <div class="modal" id="md_edit" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title mx-auto">แก้ไขใบรายการขาย</h4>
                    <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->

                </div>
                <form class="form-group" action="../query/saleslip/ss_edit.php" method="post" enctype=multipart/form-data> <!-- Modal body -->
                    <div class="modal-body ">
                        <label><i class="fa fa-id-card"></i> &nbsp; เลขที่ใบรายการขาย</label>
                        <input class="form-control" type="text" name="ss_code_edit" id="ss_code_edit" readonly required>
                        <label><i class="fa fa-clock-o"></i> &nbsp;วัน-เวลา</label>
                        <input type="datetime-local" class="form-control" name="ss_time_edit" id="ss_time_edit" required>
                        <label><i class="fa fa-usd"></i> &nbsp;ราคารวม</label>
                        <input type="text" class="form-control" name="ss_totalprice_edit" id="ss_totalprice_edit" autocomplete="off" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" required>
                        <label><i class="fa fa-usd"></i> &nbsp;ส่วนลด(บาท)</label>
                        <input type="text" class="form-control" name="ss_discount_edit" id="ss_discount_edit" autocomplete="off" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" required>
                        <label><i class="fa fa-usd"></i> &nbsp;ราคาสุทธิ</label>
                        <input type="text" class="form-control" name="ss_netprice_edit" id="ss_netprice_edit" autocomplete="off" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" required>
                        <label><i class="fa fa-credit-card"></i> &nbsp;ช่องทางการชำระเงิน</label>
                        <select class="form-control" name="pm_method_edit" id="pm_method_edit" required>
                            <option value="1">ชำระปลายทาง </option>
                            <option value="2">โอนธนาคาร </option>
                        </select>
                        <label><i class="fa fa-file-image-o"></i> &nbsp;หลักฐานการชำระเงิน</label>
                        <br>
                        <img src="" id="pm_pic_view" class="rounded img-fluid">
                        <br><br>
                        <input type="hidden" name="pm_pic_edit" id="pm_pic_edit">
                        <input type="file" class="form-control-file" name="pm_pic_edit_new" value="" aria-describedby="fileHelp">
                        <small id="fileHelp" class="form-text text-warning">*หากไม่ต้องการเปลี่ยนแปลงไม่ต้องแนบไฟล์</small>
                        <label><i class="fa fa-exchange"></i> &nbsp;สถานะการขาย</label>
                        <select class="form-control" name="ss_status_edit" id="ss_status_edit" required>
                            <option value="1">รอการอนุมัติ </option>
                            <option value="2">อนุมัติแล้ว </option>
                            <option value="3">ยกเลิก </option>
                        </select>
                        <label><i class="fa fa-exchange"></i> &nbsp;สถานะการชำระเงิน</label>
                        <select class="form-control" name="pm_status_edit" id="pm_status_edit" required>
                            <option value="1">รอการตรวจสอบ </option>
                            <option value="2">ชำระเงินแล้ว </option>
                            <option value="3">ยกเลิก </option>
                        </select>
                        <label><i class="fa fa-file-text-o"></i> &nbsp;หมายเหตุ</label>
                        <textarea class="form-control" name="ss_note_edit" id="ss_note_edit" rows="2"></textarea>
                        <label><i class="fa fa-clock-o"></i> &nbsp;เวลาการส่ง</label>
                        <select class="form-control" name="dt_code_edit" id="dt_code_edit" required>
                            <option value="">----เลือกเวลาการส่ง----</option>
                            <?php
                            $sql = "select * from deliverytime";
                            $rs = mysqli_query($conn, $sql) or die("sql deliverytime");
                            while ($row = mysqli_fetch_assoc($rs)) {
                                echo "<option value=" . $row['dt_code'] . ">" . $row["dt_name"] . "</option>";
                            }
                            ?>
                        </select>
                        <label><i class="fa fa-truck"></i> &nbsp;พื้นที่ให้บริการ</label>
                        <select class="form-control" name="sa_code_edit" id="sa_code_edit" required>
                            <option value="">----เลือกพื้นที่ให้บริการ----</option>
                            <?php
                            $sql = "select * from servicearea";
                            $rs = mysqli_query($conn, $sql) or die("sql servicearea");
                            while ($row = mysqli_fetch_assoc($rs)) {
                                echo "<option value=" . $row['sa_code'] . ">" . $row["sa_name"] . "</option>";
                            }
                            ?>
                        </select>

                        <label><i class="fa fa-address-book"></i> &nbsp; รหัสสมาชิก</label>
                        <input class="form-control" type="text" name="mb_code_edit" id="mb_code_edit" readonly required>
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success mx-auto">บันทึก</button>
                        <button type="button" class="btn btn-danger mx-auto" data-dismiss="modal">ปิด</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>