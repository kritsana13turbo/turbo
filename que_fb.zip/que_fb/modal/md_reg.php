<?php
require_once('config/connect.php');
?>
<!-- The Modal -->
<div class="row">

    <div class="modal" id="md_reg" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title mx-auto">สมัครสมาชิก</h4>
                    <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->

                </div>
                <form class="form-group" action="query/mb_reg.php" method="post">
                    <!-- Modal body -->
                    <div class="modal-body ">

                        <label><i class="fa fa-envelope"></i> &nbsp;อีเมล</label>
                        <input class="form-control" type="email" name="mb_email" placeholder="กรอก email" required>
                        <label><i class="fa fa-lock"></i> &nbsp;รหัสผ่าน</label>
                        <input class="form-control" type="password" name="mb_pass" placeholder="กรอกรหัสผ่าน" autocomplete="on" required>
                        <label><i class="fa fa-lock"></i> &nbsp;รหัสผ่านอีกครั้ง</label>
                        <input class="form-control" type="password" name="mb_pass2" placeholder="กรอกรหัสผ่านอีกครั้ง" autocomplete="on" required>
                        <input type="hidden" name="mb_type" value="1"> <!-- ระดับผู้ใช้สมาชิก -->
                        <label><i class="fa fa-address-book"></i> &nbsp;ชื่อ-สกุล</label>
                        <input class="form-control" type="text" name="mb_name" placeholder="กรอกชื่อ-สกุล" required>
                        <label><i class="fa fa-phone"></i> &nbsp;เบอร์โทร</label>
                        <input type="text" class="form-control" pattern="^0([8|9|6])([0-9]{8}$)" name="mb_phone" autocomplete="off" placeholder="กรอกเบอร์โทร 10 หลัก" required>


                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success mx-auto">สมัครสมาชิก</button>
                        <button type="button" class="btn btn-danger mx-auto" data-dismiss="modal">ปิด</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>