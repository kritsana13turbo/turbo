<?php
require_once('config/connect.php');
?>
<!-- The Modal -->
<div class="row">

    <div class="modal" id="md_login" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title mx-auto">ลงชื่อเข้าใช้</h4>
                    <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->

                </div>
                <form class="form-group" action="query/login.php" method="post">
                    <!-- Modal body -->
                    <div class="modal-body ">


                        <label><i class="fa fa-envelope"></i> &nbsp;อีเมล</label>
                        <input class="form-control" type="email" name="mb_email" placeholder="กรอก email" required>
                        <label><i class="fa fa-lock"></i> &nbsp;รหัสผ่าน</label>
                        <input class="form-control" type="password" name="mb_pass" placeholder="กรอกรหัสผ่าน" autocomplete="on" required>
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-info mx-auto">เข้าสู่ระบบ</button>
                        <button type="button" class="btn btn-danger mx-auto" data-dismiss="modal">ปิด</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>