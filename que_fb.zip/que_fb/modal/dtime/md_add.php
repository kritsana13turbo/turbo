<!-- The Modal -->
<div class="row">

    <div class="modal" id="md_add" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title mx-auto">เพิ่มเวลาจัดส่ง</h4>
                    <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->

                </div>
                <form class="form-group" action="../query/dtime/dt_add.php" method="post">
                    <!-- Modal body -->
                    <div class="modal-body ">
                        <label><i class="fa fa-address-book"></i> &nbsp;เวลาจัดส่ง</label>
                        <input class="form-control" type="text" name="dt_name" placeholder="กรอกเวลาจัดส่ง" required>
                        <label><i class="fa fa-clock-o"></i> &nbsp;เวลา</label>
                        <input type="time" class="form-control"  name="dt_time"  required>
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success mx-auto">บันทึก</button>
                        <button type="button" class="btn btn-danger mx-auto" data-dismiss="modal">ปิด</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>