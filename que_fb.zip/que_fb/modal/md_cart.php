<!-- The Modal -->
<div class="row">

    <div class="modal" id="md_cart" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title mx-auto">เมนูในตะกร้า</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                </div>
                <div class="table-responsive" id="order_table">
                    <table class="table table-hover">
                        <tr>
                            <th width="40%">เมนู</th>
                            <th width="10%">จำนวน</th>
                            <th width="20%" style="text-align:right;">ราคา</th>
                            <th width="20%" style="text-align:right;">รวม</th>
                            <th width="5%" style="text-align:center;">ลบ</th>
                        </tr>
                        <?php
                        if (!empty($_SESSION["shopping_cart"])) {
                            $total = 0;
                            foreach ($_SESSION["shopping_cart"] as $keys => $values) {
                        ?>
                                <tr>
                                    <td><?php echo $values["product_name"]; ?></td>
                                    <td><input type="text" name="quantity[]" id="quantity<?php echo $values["product_id"]; ?>cart" value="<?php echo $values["product_quantity"]; ?>" data-product_id="<?php echo $values["product_id"]; ?>" class="form-control form-control-sm quantity" /></td>
                                    <td align="right">฿ <?php echo $values["product_price"]; ?></td>
                                    <td align="right">฿ <?php echo number_format($values["product_quantity"] * $values["product_price"]); ?></td>
                                    <td><button name="delete" class="btn btn-danger btn-sm delete" id="<?php echo $values["product_id"]; ?>"><i class="fa fa-times" aria-hidden="true"></i></button></td>
                                </tr>
                            <?php
                                $total = $total + ($values["product_quantity"] * $values["product_price"]);
                            }
                            ?>
                            <tr>
                                <td colspan="3" align="right">ราคารวม</td>
                                <td align="right">฿ <?php echo number_format($total); ?></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td colspan="5" align="right">
                                    <form method="post" action="?url=cart_step1">
                                        <input type="submit" name="place_order" class="btn btn-info" value="ชำระเงิน" />
                                    </form>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>