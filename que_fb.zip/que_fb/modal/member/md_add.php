<!-- The Modal -->
<div class="row">

    <div class="modal" id="md_add" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title mx-auto">เพิ่มสมาชิก</h4>
                    <!--<button type="button" class="close" data-dismiss="modal">&times;</button>-->

                </div>
                <form class="form-group" action="../query/member/mb_add.php" method="post">
                    <!-- Modal body -->
                    <div class="modal-body ">

                        <label><i class="fa fa-envelope"></i> &nbsp;อีเมล</label>
                        <input class="form-control" type="email" name="mb_email" placeholder="กรอก email" required>
                        <label><i class="fa fa-lock"></i> &nbsp;รหัสผ่าน</label>
                        <input class="form-control" type="password" name="mb_pass" placeholder="กรอกรหัสผ่าน" required>
                        <label><i class="fa fa-users"></i> &nbsp;ระดับสมาชิก</label>
                        <select class="form-control" name="mb_type">
                            <option value="1">สมาชิก</option>
                            <option value="3">แอดมิน</option>
                        </select>
                        <label><i class="fa fa-address-book"></i> &nbsp;ชื่อ-สกุล</label>
                        <input class="form-control" type="text" name="mb_name" placeholder="กรอกชื่อ-สกุล" required>
                        <label><i class="fa fa-phone"></i> &nbsp;เบอร์โทร</label>
                        <input type="text" class="form-control" pattern="^0([8|9|6])([0-9]{8}$)" name="mb_phone" autocomplete="off" placeholder="กรอกเบอร์โทร 10 หลัก" required>
                    </div>

                    <!-- Modal footer -->
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success mx-auto">บันทึก</button>
                        <button type="button" class="btn btn-danger mx-auto" data-dismiss="modal">ปิด</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>