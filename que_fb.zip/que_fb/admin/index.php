<?php include "../session/ss_admin.php";
include '../config/setting.php'; ?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS litera slate solar cyborg sandstone lumen-->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.4.1/litera/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <!-- data table -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">
    <script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

    <!-- Icon -->
    <link rel="icon" href="<?php echo $icon_dev; ?>" type="image/x-icon"> 

    <title><?php echo $title_admin; ?></title>
</head>

<body>
    
    <div class="container-fluid">
        <?php include "../menu/mn_admin.php"; ?>
        <div class="jumbotron">
        <div class="row">
            <div class="col-sm-2"><?php include "../menu/mn_left_admin.php"; ?></div>
            <div class="col-sm-10">
                <?php if (isset($_GET['mng'])) {
                    if (file_exists("../admin/pages/" . trim($_GET['mng']) . ".php")) {
                        require_once "../admin/pages/" . trim($_GET['mng']) . ".php";
                    } else {
                        require_once "../admin/pages/mng_member.php";
                    }
                } else {
                    require_once "../admin/pages/mng_member.php";
                }  ?>
            </div>
        </div>
        </div>
    </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <!-- ใช้ 3.5.1 ข้างบนแทนแล้ว -->
    <!--<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=<?php echo $gg_api_key; ?>"></script>
    <?php
    require('../script/ggmap_script.php');
    ?>
</body>

</html>