<?php
require("../config/connect.php");
include '../script/mng_sale_script.php';
include '../modal/sale/md_add.php';
include '../modal/sale/md_edit.php';

$query = "SELECT * FROM sale 
INNER JOIN menu ON sale.m_code = menu.m_code
ORDER BY s_code ASC" or die("Error sale :" . mysqli_error($conn));
$result = mysqli_query($conn, $query);

?>


<button type="button" class="btn btn-success" data-toggle="modal" data-target="#md_add"><i class="fa fa-plus"></i> &nbsp;เพิ่มรายละเอียดการขาย</button>
<hr>
<table border="0" class="table table-striped table-bordered" id="mng_sale" align="center">
    <thead>
        <tr class="table-light">
            <th>รหัสรายละเอียดการขาย</th>
            <th>ชื่อเมนู</th>
            <th>รูป</th>
            <th>ราคา(ต่อชิ้น)</th>
            <th>จำนวน</th>
            <th>ราคารวม</th>
            <th>เลขที่ใบรายการขาย</th>
            <th style="width:5%;">แก้ไข</th>
            <th style="width:5%;">ลบ</th>
        </tr>
    </thead>
    <?php
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
            <td><?php echo $row['s_code']; ?></td>
                <td><?php echo $row['m_name']; ?></td>
                <td><img src="<?php echo '../img/menu/'.$row['m_pic']; ?>"   class="rounded img-fluid"></td>
                <td><?php echo $row['m_price']; ?></td>
                <td><?php echo $row['s_total']; ?></td>
                <td><?php echo $row['s_price']; ?></td>
                <td><?php echo $row['ss_code']; ?></td>
                <td><a href="#" data-toggle="modal" data-target="#md_edit" class="btn btn-warning btn-sm md_edit" 
                s_code="<?php echo $row['s_code']; ?>" 
                s_total="<?php echo $row['s_total']; ?>" 
                s_price="<?php echo $row['s_price']; ?>"
                m_code="<?php echo $row['m_code']; ?>"
                ss_code="<?php echo $row['ss_code']; ?>" >
                        <i class="fa fa-wrench"></i>
                    </a>
                </td>
                <td><a href="#" class="btn btn-danger btn-sm" onclick="delx('<?php echo $row['s_code']; ?>');"><i class="fa fa-trash-o" ></i></a> </td>
            <?php
        }
            ?>

            </tr>
</table>
<?php
    } else {
        echo "0 results";
    }

    mysqli_close($conn);
?>
