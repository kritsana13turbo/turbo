<?php
require("../config/connect.php");
include '../script/mng_saleslip_script.php';
include '../modal/saleslip/md_add.php';
include '../modal/saleslip/md_view1.php';
include '../modal/saleslip/md_view2.php';
include '../modal/saleslip/md_edit.php';


$query = "SELECT * FROM saleslip 
INNER JOIN deliverytime ON saleslip.dt_code = deliverytime.dt_code
INNER JOIN servicearea ON saleslip.sa_code = servicearea.sa_code
INNER JOIN member_rb ON saleslip.mb_code = member_rb.mb_code
 ORDER BY ss_code ASC" or die("Error mng_saleslip :" . mysqli_error($conn));
$result = mysqli_query($conn, $query);

?>


<button type="button" class="btn btn-success" data-toggle="modal" data-target="#md_add"><i class="fa fa-plus"></i>
    &nbsp;เพิ่มใบรายการขาย</button>
<hr>
<table border="0" class="table table-striped table-bordered" id="mng_saleslip" align="center">
    <thead>
        <tr class="table-light">
            <th>เลขที่</th>
            <th>วัน-เวลา</th>
            <th>ราคาสุทธิ</th>
            <th>ช่องทางการชำระเงิน</th>
            <th>สถานะการขาย</th>
            <th>สถานะการชำระเงิน</th>
            <th>เวลาการส่ง</th>
            <th>พื้นที่</th>
            <th>สมาชิก</th>
            <th style="width:5%;">ดู</th>
            <th style="width:5%;">แก้ไข</th>
            <th style="width:5%;">ลบ</th>
        </tr>
    </thead>
    <?php
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) { ?>
    <tr>
        <td><?php echo $row['ss_code']; ?></td>
        <td><?php echo $row['ss_time']; ?></td>
        <td><?php echo $row['ss_netprice']; ?></td>
        <?php 
            switch ($row['pm_method']) {
                case "2":
                    echo "<td><span class='badge badge-success'><i class='fa fa-university'></i> &nbsp; โอนธนาคาร</span></td>";
                break;
                case "1":
                    echo "<td><span class='badge badge-warning'><i class='fa fa-money'></i> &nbsp; ชำระปลายทาง </span></td>";
                break;
            }

            switch ($row['ss_status']) {
                case "3":
                    echo "<td><span class='badge badge-danger'><i class='fa fa-times-circle'></i> &nbsp; ยกเลิก </span></td>";
                break;
                case "2":
                    echo "<td><span class='badge badge-success'><i class='fa fa-check-circle'></i> &nbsp; อนุมัติแล้ว </span></td>";
                break;
                case "1":
                    echo "<td><span class='badge badge-warning'><i class='fa fa-spinner'></i> &nbsp; รอการอนุมัติ </span></td>";
                break;
            }

            switch ($row['pm_status']) {
                case "3":
                    echo "<td><span class='badge badge-danger'><i class='fa fa-times-circle'></i> &nbsp; ยกเลิก </span></td>";
                break;
                case "2":
                    echo "<td><span class='badge badge-success'><i class='fa fa-check-circle'></i> &nbsp; ชำระเงินแล้ว </span></td>";
                break;
                case "1":
                    echo "<td><span class='badge badge-warning'><i class='fa fa-spinner'></i> &nbsp; รอการตรวจสอบ </span></td>";
                break;
            }
        ?>
        <td><?php echo $row['dt_name']; ?></td>
        <td><?php echo $row['sa_name']; ?></td>
        <td><?php echo $row['mb_name']; ?></td>
        <td>
            <div class="btn-group">
            <button type="button" class="btn btn-info btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fa fa-eye"></i>
            </button>
            <div class="dropdown-menu">
                <a href="#" data-toggle="modal" data-target="#md_view1" class="dropdown-item md_view1" 
                    ss_code="<?php echo $row['ss_code']; ?>"
                    ss_time="<?php echo date("Y-m-d\TH:i:s", strtotime($row['ss_time'])) ?>" 
                    ss_totalprice="<?php echo $row['ss_totalprice']; ?>" 
                    ss_discount="<?php echo $row['ss_discount']; ?>" 
                    ss_netprice="<?php echo $row['ss_netprice']; ?>" 
                    pm_method="<?php echo $row['pm_method']; ?>" 
                    pm_pic="<?php echo $row['pm_pic']; ?>" 
                    ss_status="<?php echo $row['ss_status']; ?>" 
                    pm_status="<?php echo $row['pm_status']; ?>" 
                    ss_note="<?php echo $row['ss_note']; ?>" 
                    dt_code="<?php echo $row['dt_code']; ?>" 
                    sa_code="<?php echo $row['sa_code']; ?>" 
                    mb_code="<?php echo $row['mb_code']; ?>">
                    ดูใบรายการขายแบบเต็ม
                </a>
                <a href="#" data-toggle="modal" data-target="#md_view2" class="dropdown-item md_view2" 
                    ss_code="<?php echo $row['ss_code']; ?>" >
                    ดูรายละเอียดการขาย
                </a>
            </div>
            </div>
        </td>
        <td><a href="#" data-toggle="modal" data-target="#md_edit" class="btn btn-warning btn-sm md_edit"
                    ss_code="<?php echo $row['ss_code']; ?>"
                    ss_time="<?php echo date("Y-m-d\TH:i:s", strtotime($row['ss_time'])) ?>" 
                    ss_totalprice="<?php echo $row['ss_totalprice']; ?>" 
                    ss_discount="<?php echo $row['ss_discount']; ?>" 
                    ss_netprice="<?php echo $row['ss_netprice']; ?>" 
                    pm_method="<?php echo $row['pm_method']; ?>" 
                    pm_pic="<?php echo $row['pm_pic']; ?>" 
                    ss_status="<?php echo $row['ss_status']; ?>" 
                    pm_status="<?php echo $row['pm_status']; ?>" 
                    ss_note="<?php echo $row['ss_note']; ?>" 
                    dt_code="<?php echo $row['dt_code']; ?>" 
                    sa_code="<?php echo $row['sa_code']; ?>" 
                    mb_code="<?php echo $row['mb_code']; ?>">
                <i class="fa fa-wrench"></i>
            </a>
        </td>
        <td><a href="#" class="btn btn-danger btn-sm"
                onclick="delx('<?php echo $row['ss_code']; ?>','<?php echo $row['pm_pic']; ?>');"><i
                    class="fa fa-trash-o"></i></a> </td>
        <?php
        }
            ?>

    </tr>
</table>
<?php
    } else {
        echo "0 results";
    }

    mysqli_close($conn);
?>
