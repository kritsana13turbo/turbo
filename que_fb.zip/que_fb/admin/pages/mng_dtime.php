<?php
require("../config/connect.php");
include '../script/mng_dtime_script.php';
include '../modal/dtime/md_add.php';
include '../modal/dtime/md_edit.php';

$query = "SELECT * FROM deliverytime ORDER BY dt_code ASC" or die("Error dtime :" . mysqli_error($conn));
$result = mysqli_query($conn, $query);

?>


<button type="button" class="btn btn-success" data-toggle="modal" data-target="#md_add"><i class="fa fa-plus"></i> &nbsp;เพิ่มเวลาจัดส่ง</button>
<hr>
<table border="0" class="table table-striped table-bordered" id="mng_dtime" align="center">
    <thead>
        <tr class="table-light">
            <th>รหัสเวลาจัดส่ง</th>
            <th>ชื่อเวลาจัดส่ง</th>
            <th>เวลา</th>
            <th style="width:5%;">แก้ไข</th>
            <th style="width:5%;">ลบ</th>
        </tr>
    </thead>
    <?php
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['dt_code']; ?></td>
                <td><?php echo $row['dt_name']; ?></td>
                <td><?php echo $row['dt_time']; ?></td>
                <td><a href="#" data-toggle="modal" data-target="#md_edit" class="btn btn-warning btn-sm md_edit" 
                data-code="<?php echo $row['dt_code']; ?>" 
                data-name="<?php echo $row['dt_name']; ?>" 
                data-time="<?php echo $row['dt_time']; ?>" >
                        <i class="fa fa-wrench"></i>
                    </a>
                </td>
                <td><a href="#" class="btn btn-danger btn-sm" onclick="delx('<?php echo $row['dt_code']; ?>');"><i class="fa fa-trash-o" ></i></a> </td>
            <?php
        }
            ?>

            </tr>
</table>
<?php
    } else {
        echo "0 results";
    }

    mysqli_close($conn);
?>
