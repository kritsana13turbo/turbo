<?php
require("../config/connect.php");
include '../script/mng_member_script.php';
include '../modal/member/md_add.php';
include '../modal/member/md_edit.php';

$query = "SELECT * FROM member_rb ORDER BY mb_code ASC" or die("Error mng_member :" . mysqli_error($conn));
$result = mysqli_query($conn, $query);

?>


<button type="button" class="btn btn-success" data-toggle="modal" data-target="#md_add"><i class="fa fa-plus"></i> &nbsp;เพิ่มสมาชิก</button>
<hr>
<table border="0" class="table table-striped table-bordered" id="mng_member" align="center">
    <thead>
        <tr class="table-light">
            <th>รหัสสมาชิก</th>
            <th>email</th>
            <th>password</th>
            <th>ชื่อสมาชิก</th>
            <th>เบอร์โทร</th>
            <th>ระดับสมาชิก</th>
            <th style="width:5%;">แก้ไข</th>
            <th style="width:5%;">ลบ</th>
        </tr>
    </thead>
    <?php
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['mb_code']; ?></td>
                <td><?php echo $row['mb_email']; ?></td>
                <td><?php echo $row['mb_pass']; ?></td>
                <td><?php echo $row['mb_name']; ?></td>
                <td><?php echo $row['mb_phone']; ?></td>
                <?php
                switch ($row['mb_type']) {
                    case "3":
                        echo "<td><span class='badge badge-danger'> แอดมิน </span></td>";
                        break;
                    case "1":
                        echo "<td><span class='badge badge-success'> สมาชิก </span></td>";
                        break;
                    default:
                        echo "<td> สมาชิก </td>";
                } ?>
                <td><a href="#" data-toggle="modal" data-target="#md_edit" class="btn btn-warning btn-sm md_edit" data-code="<?php echo $row['mb_code']; ?>" data-email="<?php echo $row['mb_email']; ?>" data-pass="<?php echo $row['mb_pass']; ?>" data-name="<?php echo $row['mb_name']; ?>" data-phone="<?php echo $row['mb_phone']; ?>" data-type="<?php echo $row['mb_type']; ?>">
                        <i class="fa fa-wrench"></i>
                    </a>
                </td>
                <td><a href="#" class="btn btn-danger btn-sm" onclick="delx('<?php echo $row['mb_code']; ?>');"><i class="fa fa-trash-o" ></i></a> </td>
            <?php
        }
            ?>

            </tr>
</table>
<?php
    } else {
        echo "0 results";
    }

    mysqli_close($conn);
?>
