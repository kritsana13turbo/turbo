<?php
require("../config/connect.php");
include '../script/mng_field_scipt.php'; 
include '../modal/field/md_add.php';
include '../modal/field/md_edit.php';

$query = "SELECT * FROM field ORDER BY id_field ASC" or die("Error mng_field :" . mysqli_error($conn));
$result = mysqli_query($conn, $query);

?>


<button type="button" class="btn btn-success" data-toggle="modal" data-target="#md_add"><i class="fa fa-plus"></i> &nbsp;เพิ่มสนาม</button>
<hr>
<table border="0" class="table table-striped table-bordered" id="mng_menu" align="center">
    <thead>
        <tr class="table-light">
            <th>รหัสสนาม</th>
            <th>ชื่อสนาม</th>
            <th>สถานะสนาม</th>
            <th style="width:5%;">แก้ไข</th>
            <th style="width:5%;">ลบ</th>
        </tr>
    </thead>
    <?php
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['id_field']; ?></td>
                <td><?php echo $row['name_field']; ?></td>
                <td><?php echo $row['status_field']; ?></td>
                <td><a href="#" data-toggle="modal" data-target="#md_edit" class="btn btn-warning btn-sm md_edit" 
                data-code="<?php echo $row['id_field']; ?>" 
                data-name="<?php echo $row['name_field']; ?>" 
                data-status="<?php echo $row['status_field']; ?>">
                <i class="fa fa-wrench"></i>
                    </a>
                </td>

                <td><a href="#" class="btn btn-danger btn-sm" onclick="delx('<?php echo $row['id_field']; ?>');"><i class="fa fa-trash-o" ></i></a> </td>

            <?php
        }
            ?>

            </tr>
</table>
<?php
    } else {
        echo "0 results";
    }

    mysqli_close($conn);
?>
