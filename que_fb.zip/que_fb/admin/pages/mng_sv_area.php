<?php
require("../config/connect.php");
include '../script/mng_sv_area_script.php';
include '../modal/sv_area/md_add.php';
include '../modal/sv_area/md_edit.php';

$query = "SELECT * FROM servicearea ORDER BY sa_code ASC" or die("Error sv_area :" . mysqli_error($conn));
$result = mysqli_query($conn, $query);

?>


<button type="button" class="btn btn-success" data-toggle="modal" data-target="#md_add"><i class="fa fa-plus"></i> &nbsp;เพิ่มพื้นที่ให้บริการ</button>
<hr>
<table border="0" class="table table-striped table-bordered" id="mng_sv_area" align="center">
    <thead>
        <tr class="table-light">
            <th>รหัสพื้นที่</th>
            <th>ชื่อพื้นที่</th>
            <th>ค่าบริการ</th>
            <th style="width:5%;">แก้ไข</th>
            <th style="width:5%;">ลบ</th>
        </tr>
    </thead>
    <?php
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['sa_code']; ?></td>
                <td><?php echo $row['sa_name']; ?></td>
                <td><?php echo $row['sa_cost']; ?></td>
                <td><a href="#" data-toggle="modal" data-target="#md_edit" class="btn btn-warning btn-sm md_edit" 
                data-code="<?php echo $row['sa_code']; ?>" 
                data-name="<?php echo $row['sa_name']; ?>" 
                data-cost="<?php echo $row['sa_cost']; ?>" >
                        <i class="fa fa-wrench"></i>
                    </a>
                </td>
                <td><a href="#" class="btn btn-danger btn-sm" onclick="delx('<?php echo $row['sa_code']; ?>');"><i class="fa fa-trash-o" ></i></a> </td>
            <?php
        }
            ?>

            </tr>
</table>
<?php
    } else {
        echo "0 results";
    }

    mysqli_close($conn);
?>
