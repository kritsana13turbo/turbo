<?php
require("../config/connect.php");

$query = "SELECT  * FROM promotion" or die("Error promotion :" . mysqli_error($conn));
$result = mysqli_query($conn, $query);

?>

<?php
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
?>

        <form class="form-group"  action="../query/promotion/p_edit.php" method="post">
            <!-- Modal body -->
                <div class="custom-control custom-switch">
                    <input type="checkbox" class="custom-control-input" id="customSwitch1" name="p_status" value="1" <?php if ($row['p_status'] == 1) {
                                                                                                                            echo 'checked';
                                                                                                                        } ?>>
                    <label class="custom-control-label" for="customSwitch1">เปิด/ปิด การใช้งานโปรโมชัน</label>
                </div>
                <hr>
                <input type="hidden" name="p_code" value="<?php echo $row['p_code']; ?>" required>
                <label><i class="fa fa-address-book"></i> &nbsp;ชื่อโปรโมชัน</label>
                <input class="form-control" type="text" name="p_name" value="<?php echo $row['p_name']; ?>" required>
                <label><i class="fa fa-calendar"></i> &nbsp;วันที่เริ่ม</label>
                <input class="form-control" type="date" name="p_startdate" value="<?php echo $row['p_startdate']; ?>" required>
                <label><i class="fa fa-calendar"></i> &nbsp;วันที่สิ้นสุด</label>
                <input class="form-control" type="date" name="p_enddate" value="<?php echo $row['p_enddate']; ?>" required>
                <label><i class="fa fa-usd"></i> &nbsp;ราคารวมขั้นต่ำ</label>
                <input type="text" class="form-control" name="mm_totalprice" value="<?php echo $row['mm_totalprice']; ?>" autocomplete="off" onkeypress="return (event.charCode !=8 && event.charCode ==0 || (event.charCode >= 48 && event.charCode <= 57))" required>
                <label><i class="fa fa-usd"></i> &nbsp;ส่วนลด(%)</label>
                <input type="number" class="form-control" name="dc_percentage" value="<?php echo $row['dc_percentage']; ?>" autocomplete="off" min=0 max=100>
                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success mx-left">ปรับปรุง</button>
                </div>
        </form>

<?php
    }
} else {
    echo "No promotion";
}

mysqli_close($conn);
?>