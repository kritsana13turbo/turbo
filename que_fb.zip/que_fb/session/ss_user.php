<?php
session_start();
if (isset($_SESSION["email"]) && isset($_SESSION["pass"])) {
    $email = $_SESSION['email'];
    $pass = $_SESSION['pass'];
    $name = $_SESSION['name'];
    $type = $_SESSION['type'];

    if ($type != 1) {
        session_destroy();
        ?>
        <script>
            window.alert("ระดับผู้ใช้ไม่ถูกต้อง!");
            window.location = 'index.php';
        </script>
    <?php
}
} else {
    ?>
    <script>
        window.alert("คุณยังไม่ได้เข้าสู่ระบบ!");
        window.location = '../index.php';
    </script>
<?php }
include "menu/mn_user.php";?>