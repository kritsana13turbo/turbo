<?php
session_start();

$email = null;
$pass = null;
$name = null;
$type = null;

if (isset($_SESSION["email"]) && isset($_SESSION["pass"])) {
    $email = $_SESSION['email'];
    $pass = $_SESSION['pass'];
    $name = $_SESSION['name'];
    $type = $_SESSION['type'];
    $mb_code = $_SESSION['mb_code'];
}

?>