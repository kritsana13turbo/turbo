<?php include "session/ss_user.php";
include 'pages/img_slide.php';

$query = "SELECT * FROM menu ORDER BY m_code ASC" or die("Error user_menu :");
$result = mysqli_query($conn, $query);

$querypro = "SELECT * FROM promotion" or die("Error user_menu :");
$resultpro = mysqli_query($conn, $querypro);
$rowp = mysqli_fetch_assoc($resultpro)

?>
<!DOCTYPE html>
<html>
<head>
    <title>ตารางการจอง</title>
</head>
<body>
    <h1>ตารางการจอง</h1>
    
    <h3>ชั่วโมงละ650บาท</h3>
    <form method="post" action="process_booking.php">
        <table border="1">
            <tr>
                <th>เวลา/สนาม</th>
                <th>16:00-17:00</th>
                <th>17:00-18:00</th>
                <th>18:00-19:00</th>
                <th>19:00-20:00</th>
                <th>20:00-21:00</th>
                <th>21:00-22:00</th>
                <th>22:00-23:00</th>
            </tr>
            <?php
            // ตัวอย่างข้อมูลจองจากฐานข้อมูลหรือข้อมูลจากอาเรย์
            $bookings = array(
                array('สนาม1'),
                array('สนาม2'),
                array('สนาม3'),
            );

            foreach ($bookings as $booking) {
                echo "<tr>";
                echo "<td>" . $booking[0] . "</td>";
              
                echo "<td><input type='checkbox' name='booking[]' value='" . implode(',', $booking) . "'></td>";
                echo "<td><input type='checkbox' name='booking[]' value='" . implode(',', $booking) . "'></td>";
                echo "<td><input type='checkbox' name='booking[]' value='" . implode(',', $booking) . "'></td>";
                echo "<td><input type='checkbox' name='booking[]' value='" . implode(',', $booking) . "'></td>";
                echo "<td><input type='checkbox' name='booking[]' value='" . implode(',', $booking) . "'></td>";
                echo "<td><input type='checkbox' name='booking[]' value='" . implode(',', $booking) . "'></td>";
                echo "<td><input type='checkbox' name='booking[]' value='" . implode(',', $booking) . "'></td>";
                echo "</tr>";
            }
    
            ?>
        </table>
        <input type="submit" name="submit" value="ยืนยันการจอง">
    </form>
</body>
</html>
