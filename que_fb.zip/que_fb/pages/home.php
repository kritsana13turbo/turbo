<?php include "session/ss_user.php";
include 'pages/img_slide.php';

$query = "SELECT * FROM menu ORDER BY m_code ASC" or die("Error user_menu :");
$result = mysqli_query($conn, $query);

$querypro = "SELECT * FROM promotion" or die("Error user_menu :");
$resultpro = mysqli_query($conn, $querypro);
$rowp = mysqli_fetch_assoc($resultpro)

?>
<br>
<div class="alert alert-dismissible alert-success">
    <h4 class="alert-heading"><i class="fa fa-bullhorn"></i> โปรโมชัน !</h4>
    <p class="mb-0">
        <?php
        //$start_date = $rowp['p_startdate'];
        //$end_date = $rowp['p_enddate'];
        //$date_from_user = date("Y-m-d");

        //$promotion = check_in_range($start_date, $end_date, $date_from_user);

        //เช็คว่าเปิดใช้งานโปรโมชั่น และตรงกับวันที่ปัจจุบันหรือไม่
        if (($rowp['p_status'] == 1) and $promotion) {
            echo $rowp['p_name'];
        } else {
            echo "วันนี้ทางร้านไม่มีโปรโมชันครับ";
        }
        ?>
    </p>
</div>
<div class="jumbotron">
    <div class="row mt-2 pb-3">
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) { ?>
                <div class="col-lg-3">
                    <div class="card border-success mb-3">
                        <div class="card-header"><?php echo $row['m_name']; ?></div>
                        <img src="img/menu/<?php echo $row['m_pic']; ?>" class="img-fluid">
                        <div class="card-body">
                            <h4 class="card-title"><?php echo '฿' . number_format($row['m_price']); ?></h4>
                            <p class="card-text"><?php echo $row['m_detail']; ?></p>
                            <input type="hidden" name="quantity" id="quantity<?php echo $row["m_code"]; ?>" value="1" />
                            <input type="hidden" name="hidden_name" id="name<?php echo $row["m_code"]; ?>" value="<?php echo $row["m_name"]; ?>" />
                            <input type="hidden" name="hidden_price" id="price<?php echo $row["m_code"]; ?>" value="<?php echo $row["m_price"]; ?>" />

                            <a class="btn btn-success btn-block add_to_cart text-white" id="<?php echo $row['m_code']; ?>">
                                <i class="fa fa-cart-arrow-down" aria-hidden="true"></i>
                                หยิบลงตะกร้้า
                            </a>
                        </div>
                    </div>
                </div>

        <?php
            }
        } else {
            echo "ไม่พบเมนู";
        }
        mysqli_close($conn);
        ?>
    </div>
</div>
</div>