<?php include "session/ss_user.php";
include 'pages/img_slide.php';
include 'script/user_saleslip_script.php';
include 'modal/user/md_view1.php';
include 'modal/user/md_view2.php';

$querypro = "SELECT * FROM promotion" or die("Error user_menu :");
$resultpro = mysqli_query($conn, $querypro);
$rowp = mysqli_fetch_assoc($resultpro);


//$promotion_now = false;
//$start_date = $rowp['p_startdate'];
//$end_date = $rowp['p_enddate'];
//$date_from_user = date("Y-m-d");

//$promotion = check_in_range($start_date, $end_date, $date_from_user);


//เช็คว่าเปิดใช้งานโปรโมชั่น และตรงกับวันที่ปัจจุบันหรือไม่
if (($rowp['p_status'] == 1) and $promotion) {
    $promotion_now = true;
}


?>
<br>
<div class="alert alert-dismissible alert-success">
    <h4 class="alert-heading"><i class="fa fa-bullhorn"></i> โปรโมชัน !</h4>
    <p class="mb-0">
        <?php
        if ($promotion_now) {
            echo $rowp['p_name'];
        } else {
            echo "วันนี้ทางร้านไม่มีโปรโมชันครับ";
        }
        ?>
    </p>
</div>
<div class="jumbotron">


    <?php
    if (isset($_POST["place_order"])) {  ?>

        <div class="card mb-3">
            <h3 class="card-header">การจัดส่ง</h3>
            <div class="card-body">
                <form class="form-group" action="?url=cart_step2" method="post" >
                <label><font color="e80000"> &nbsp;*หากต้องการแก้ไขที่อยู่ โปรดแก้ไขก่อนชำระเงิน</font></label><br>
                    <label><i class="fa fa-clock-o"></i> &nbsp;เวลาการส่ง</label>
                    <select class="form-control" name="dt_code" required>
                        <option value="">----เลือกเวลาการส่ง----</option>
                        <?php
                        $sql = "select * from deliverytime";
                        $rs = mysqli_query($conn, $sql) or die("sql deliverytime");
                        while ($rowd = mysqli_fetch_assoc($rs)) {
                            echo "<option value=" . $rowd['dt_code'] . ">" . $rowd["dt_name"] . "</option>";
                        }
                        ?>
                    </select>
                    <label><i class="fa fa-truck"></i> &nbsp;สนามที่ต้องส่ง</label>
                    <select class="form-control" name="sa_code" required>
                        <option value="">----เลือกสนาม----</option>
                        <?php
                        $sql = "select * from servicearea";
                        $rs = mysqli_query($conn, $sql) or die("sql servicearea");
                        while ($rows = mysqli_fetch_assoc($rs)) {
                            echo "<option value=" . $rows['sa_code'] . ">" . $rows["sa_name"] . "</option>";
                        }
                        ?>
                    </select>
                    <br>
                    <input type="submit" name="place_order" class="btn btn-success float-right"  value="ต่อไป" />
                </form>
            <?php
        }
            ?>
            </div>
        </div>
</div>