<?php include "session/ss_user.php";
include 'pages/img_slide.php';
include 'script/user_saleslip_script.php';
include 'modal/user/md_view1.php';
include 'modal/user/md_view2.php';

$query = "SELECT * FROM saleslip 
INNER JOIN deliverytime ON saleslip.dt_code = deliverytime.dt_code
INNER JOIN servicearea ON saleslip.sa_code = servicearea.sa_code
INNER JOIN member_rb ON saleslip.mb_code = member_rb.mb_code
WHERE member_rb.mb_code = '$mb_code'
 ORDER BY ss_code ASC" or die("Error user_saleslip :" . mysqli_error($conn));
$result = mysqli_query($conn, $query);

?>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">ตรวจสอบคำสั่งซื้อ</a>
</nav>
<div class="jumbotron">
    <table border="0" class="table table-striped table-bordered" id="user_saleslip" align="center">
        <thead>
            <tr class="table-light">
                <th>#</th>
                <th>เวลาสั่ง</th>
                <th>ราคาสุทธิ</th>
                <th>เวลาส่ง</th>
                <th style="width:5%;">ดู</th>
                <th style="width:5%;">ยกเลิก</th>
            </tr>
        </thead>
        <?php
        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) { ?>
                <tr>
                    <td><?php echo $row['ss_code']; ?></td>
                    <td><?php echo $row['ss_time']; ?></td>
                    <td><?php echo $row['ss_netprice']; ?></td>

                    <td><?php echo $row['dt_name']; ?></td>
                    <td>
                        <div class="btn-group dropleft">
                            <button type="button" class="btn btn-info btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fa fa-eye"></i>
                            </button>
                            <div class="dropdown-menu">
                                <a href="#" data-toggle="modal" data-target="#md_view1" class="dropdown-item md_view1" ss_code="<?php echo $row['ss_code']; ?>" ss_time="<?php echo date("Y-m-d\TH:i:s", strtotime($row['ss_time'])) ?>" ss_totalprice="<?php echo $row['ss_totalprice']; ?>" ss_discount="<?php echo $row['ss_discount']; ?>" ss_netprice="<?php echo $row['ss_netprice']; ?>" pm_method="<?php echo $row['pm_method']; ?>" pm_pic="<?php echo $row['pm_pic']; ?>" ss_status="<?php echo $row['ss_status']; ?>" pm_status="<?php echo $row['pm_status']; ?>" ss_note="<?php echo $row['ss_note']; ?>" dt_code="<?php echo $row['dt_code']; ?>" sa_code="<?php echo $row['sa_code']; ?>" mb_code="<?php echo $row['mb_code']; ?>">
                                    รายละเอียดคำสั่งซื้อ
                                </a>
                                <a href="#" data-toggle="modal" data-target="#md_view2" class="dropdown-item md_view2" ss_code="<?php echo $row['ss_code']; ?>">
                                    รายการเมนูที่ซื้อ
                                </a>
                            </div>
                        </div>
                    </td>
                    <td><a href="#" class="btn btn-danger btn-sm" onclick="delx('<?php echo $row['ss_code']; ?>');"><i class="fa fa-times"></i>&nbsp;ยกเลิก</a> </td>
                <?php
            }
                ?>

                </tr>
    </table>
</div>
<?php
        }
        mysqli_close($conn);
?>