<?php include "session/ss_user.php";
include 'pages/img_slide.php';
include 'script/user_saleslip_script.php';
include 'modal/user/md_view1.php';
include 'modal/user/md_view2.php';

$querypro = "SELECT * FROM promotion" or die("Error user_promo :");
$resultpro = mysqli_query($conn, $querypro);
$rowp = mysqli_fetch_assoc($resultpro);


//$promotion_now = false;
//$start_date = $rowp['p_startdate'];
//$end_date = $rowp['p_enddate'];
//$date_from_user = date("Y-m-d");

//$promotion = check_in_range($start_date, $end_date, $date_from_user);
//หมายเหตุ
$ss_note = '';
//เช็คว่าเปิดใช้งานโปรโมชั่น และตรงกับวันที่ปัจจุบันหรือไม่
if (($rowp['p_status'] == 1) and $promotion) {
    $promotion_now = true;
}


?>
<br>
<div class="alert alert-dismissible alert-success">
    <h4 class="alert-heading"><i class="fa fa-bullhorn"></i> โปรโมชัน !</h4>
    <p class="mb-0">
        <?php
        if ($promotion_now) {
            echo $rowp['p_name'];
        } else {
            echo "วันนี้ทางร้านไม่มีโปรโมชันครับ";
        }
        ?>
    </p>
</div>
<div class="jumbotron">

    <?php
    //รับค่าการจัดส่ง
    $dt_code = $_POST["dt_code"];
    $sa_code = $_POST["sa_code"];

    $querysa = "SELECT sa_cost FROM servicearea WHERE sa_code = '$sa_code'" or die("Error user_sa :");
    $resultsa = mysqli_query($conn, $querysa);
    $rowsa = mysqli_fetch_assoc($resultsa);
    //ค่าจัดส่ง
    $sa_cost =  $rowsa['sa_cost'];
    if (isset($_POST["place_order"])) {  ?>
        <div class="card mb-3">
            <h3 class="card-header">รายการสั่งซื้อ</h3>
            <div class="card-body">
                <div class="table-responsive" id="order_table">
                    <table class="table table-hover">
                        <tr>
                            <th width="40%">เมนู</th>
                            <th width="10%" style="text-align:right;">จำนวน</th>
                            <th width="20%" style="text-align:right;">ราคา</th>
                            <th width="20%" style="text-align:right;">รวม</th>
                        </tr>
                        <?php
                        if (!empty($_SESSION["shopping_cart"])) {
                            $total = 0;
                            foreach ($_SESSION["shopping_cart"] as $keys => $values) {
                        ?>
                                <tr>
                                    <td><?php echo $values["product_name"]; ?></td>
                                    <td align="right"><?php echo $values["product_quantity"]; ?></td>
                                    <td align="right">฿ <?php echo $values["product_price"]; ?></td>
                                    <td align="right">฿ <?php echo number_format($values["product_quantity"] * $values["product_price"]); ?></td>
                                </tr>
                            <?php
                                $total = $total + ($values["product_quantity"] * $values["product_price"]);
                            }
                            ?>
                            <tr>
                                <td colspan="3" align="right"><strong>ราคารวม</strong></td>
                                <td align="right">฿ <?php echo number_format($total); ?></td>
                            </tr>
                            <?php
                            if ($promotion_now and ($rowp['mm_totalprice']  <= $total)) {
                                $discount = $total * (0.01 * $rowp['dc_percentage']);
                                $netprice = ($total - $discount) + $sa_cost;
                                $ss_note = $rowp['p_name'];//ใส่หมายเหตุ
                                echo '<tr>
                                        <td colspan="3" align="right"><strong>ส่วนลดจากโปรโมชัน (' . $rowp['dc_percentage'] . '%)</strong></td>
                                        <td align="right"><font color="#FF0000"> ฿ ' . number_format($discount) . '</font></td>
                                      </tr>';
                            }else{
                                $netprice = $total + $sa_cost;
                            }
                            ?>
                            <tr>
                                <td colspan="3" align="right"><strong>ค่าสั่งซื่อ</strong></td>
                                <td align="right">฿ <?php echo number_format($sa_cost); ?></td>
                            </tr>
                            <tr>
                                <td colspan="3" align="right"><strong>ราคาสุทธิ</strong></td>
                                <td align="right">
                                    <font color="#228B22"> ฿ <?= number_format($netprice) ?></font>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="4" align="right"><a href="?url=home" class="btn btn-success"><i class="fa fa-plus"></i>&nbsp;&nbsp;เพิ่มเมนูลงตะกร้า</a> </td>
                            <tr>
                            <?php
                        }
                            ?>
                    </table>
                </div>

            </div>
        </div>
        <div class="card mb-3">
            <h3 class="card-header">บัญชีธนาคาร</h3>
            <div class="card-body">
                <ul class="list-group list-group-flush">
                    <li class="list-group-item">
                        <h5>
                            <img src='<?php echo $banklogo ?>' class="img-fluid">
                            <?php echo $bankname ?>
                        </h5>
                    </li>
                    <li class="list-group-item"><strong>เลขที่บัญชี : </strong><?php echo $banknumber ?></li>
                    <li class="list-group-item"><strong>ชื่อบัญชี : </strong><?php echo $bank_adminname ?></li>
                </ul>
            </div>
        </div>
        <div class="card mb-3">
            <h3 class="card-header">การชำระเงิน</h3>
            <div class="card-body">
                <form class="form-group" action="query/payment_order.php" method="post" enctype=multipart/form-data> <!-- Modal body -->
                    <input type="hidden" name="ss_totalprice" value="<?= $total ?>">
                    <input type="hidden" name="ss_discount" value="<?= $discount ?>">
                    <input type="hidden" name="ss_netprice" value="<?= $netprice ?>">
                    <label><i class="fa fa-credit-card"></i> &nbsp;ช่องทางการชำระเงิน</label>
                    <select class="form-control" name="pm_method">
                        <option value="1">ชำระปลายทาง </option>
                        <option value="2">โอนธนาคาร </option>
                    </select>
                    <label><i class="fa fa-file-image-o"></i> &nbsp;หลักฐานการชำระเงิน</label>
                    <input type="file" class="form-control-file" name="pm_pic" aria-describedby="fileHelp">
                    <small id="fileHelp" class="form-text text-danger">*หากชำระปลายทางไม่ต้องแนบ</small>
                    <input type="hidden" name="ss_status" value="1">
                    <input type="hidden" name="pm_status" value="1">
                    <input type="hidden" name="ss_note" value="<?php echo $ss_note; ?>">
                    <input type="hidden" name="dt_code" value="<?php echo $dt_code; ?>">
                    <input type="hidden" name="sa_code" value="<?php echo $sa_code; ?>">
                    <input type="hidden" type="text" name="mb_code" value="<?php echo $mb_code ?>">
                
                <button type="submit" class="btn btn-success mx-auto float-right">ยืนยันการชำระเงิน</button>
                </form>
            <?php
        }
            ?>
            </div>
        </div>
</div>