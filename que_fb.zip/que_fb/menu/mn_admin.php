
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <a class="navbar-brand" href="?url=home">ระบบจัดการข้อมูล <?php echo $logo_name;?></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor03"
                aria-controls="navbarColor03" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarColor03">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" ><?php echo "สวัสดีคุณ ".$name; ?></a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="#" onclick="logoutx();">ออกจากระบบ</a>
                    </li>
                </ul>
            </div>
        </nav>
        <script type="text/javascript">
        function logoutx() {
            swal({
                title: "คุณต้องการอกจากระบบใช่มั้ย ?",
                text: "หากกด OK จะทำการออกจากระบบทันที!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((okx) => {
            if (okx) {
                swal("คุณทำการออกจากระบบเรียบร้อยแล้ว !", {
                icon: "success",
                }).then(function() {
                window.location.href="../query/logout.php"
            });
            } else {
                swal("คุณยังอยู่ต่อในระบบ!",{
                    icon: "success",
                });
            }
            });
        }
</script>
