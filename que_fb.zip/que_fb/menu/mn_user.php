<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top ">
    <a class="navbar-brand" href="#"><?php echo $logo_name; ?></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor03" aria-controls="navbarColor03" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarColor03">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
                <a class="nav-link" href="?url=home">หน้าหลัก<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link"><?php echo "สวัสดีคุณ " . $name; ?></a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="?url=field">จองสนาม</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="?url=saleslip_member">ตรวจสอบคำสั่งซื้อ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" 
                <?php if (($_GET['url'] != 'cart_step1'))
                {?>
                data-toggle="modal" 
                data-target="#md_cart" 
                <?php } ?>
                href="#">
                    <i class="fa fa-shopping-cart"></i>&nbsp;&nbsp;<span class="badge badge-pill badge-danger "><b>
                                <?php if (isset($_SESSION["shopping_cart"])) {
                                    echo $_SESSION["num_order"];
                                } else {
                                    echo '0';
                                } ?>
                            </b></span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#" onclick="logoutx();">ออกจากระบบ</a>
            </li>
        </ul>
    </div>
</nav>
<script type="text/javascript">
    function logoutx() {
        swal({
                title: "คุณต้องการอกจากระบบใช่มั้ย ?",
                text: "หากกด OK จะทำการออกจากระบบทันที!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((okx) => {
                if (okx) {
                    swal("คุณทำการออกจากระบบเรียบร้อยแล้ว !", {
                        icon: "success",
                    }).then(function() {
                        window.location.href = "query/logout.php"
                    });
                } else {
                    swal("คุณยังอยู่ต่อในระบบ!", {
                        icon: "success",
                    });
                }
            });
    }
</script>