
<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top ">
    <a class="navbar-brand" href="?url=index"><?php echo $logo_name; ?></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor03" aria-controls="navbarColor03" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarColor03">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
                <a class="nav-link" href="?url=index">หน้าหลัก<span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="modal" data-target="#md_login" href="#">ลงชื่อเข้าใช้</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="modal" data-target="#md_reg" href="#">สมัครสมาชิก</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#"><i class="fa fa-shopping-cart"></i>&nbsp;&nbsp;<span class="badge badge-pill badge-danger"><b>0</b></span></a>
            </li>
        </ul>
    </div>
</nav>
