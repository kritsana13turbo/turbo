<ul class="list-group">
  <a href="?mng=mng_member" class="list-group-item list-group-item-action bg-light"><i class="fa fa-users" style="color:#75df26"></i> &nbsp;จัดการสมาชิก</a>
  <a href="?mng=mng_field" class="list-group-item list-group-item-action bg-light"><i class="fa fa-calendar-check-o" style="color:#a83b00"></i> &nbsp;จัดการสนาม</a>
  <a href="?mng=mng_timefield" class="list-group-item list-group-item-action bg-light"><i class="fa fa-calendar-check-o" style="color:#a83b00"></i> &nbsp;จัดการเวลาใช้สนาม</a>
  <a href="?mng=mng_reservefield" class="list-group-item list-group-item-action bg-light"><i class="fa fa-calendar-o" style="color:#a83b00"></i> &nbsp;จัดการการจองสนาม</a>
  <a href="?mng=mng_sv_area" class="list-group-item list-group-item-action bg-light"><i class="fa fa-futbol-o" style="color:#0caeb0"></i> &nbsp;จัดการพื้นที่ส่งของ</a>
  <a href="?mng=mng_dtime" class="list-group-item list-group-item-action bg-light"><i class="fa fa-clock-o" style="color:#009ef0"></i> &nbsp;จัดการเวลาจัดส่ง</a>
  <a href="?mng=mng_menu" class="list-group-item list-group-item-action bg-light"><i class="fa fa-shopping-bag" style="color:#f17700"></i> &nbsp;จัดการเมนู</a>
  <a href="?mng=mng_saleslip" class="list-group-item list-group-item-action bg-light"><i class="fa fa-file-text" style="color:#f1b500"></i> &nbsp;จัดการใบรายการขาย</a>
  <a href="?mng=mng_sale" class="list-group-item list-group-item-action bg-light"><i class="fa fa-list" style="color:#850e90"></i> &nbsp;จัดการรายละเอียดการขาย</a>

</ul>
<br>