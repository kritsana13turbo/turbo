<script>
    $(document).ready(function() {
        $('#mng_field').DataTable({
            "aaSorting": [
                [0, 'ASC']
            ],
            //"lengthMenu":[[20,50, 100, -1], [20,50, 100,"All"]]
        });
    });
</script>
<script>
    $(document).on('draw.dt', function() {
        $('.md_edit').click(function() {
            var id_field = $(this).attr('data-code');
            var name_field = $(this).attr('data-name');
            var status_field = $(this).attr('data-status');


            $('#id_field').val(id_field);
            $('#name_field').val(name_field);
            $('#status_field').val(status_field);


        });
    });
</script>
<script type="text/javascript">
    function delx(code) {
        swal({
                title: "คุณต้องลบข้อมูลสนามใช่มั้ย ?",
                text: "ข้อมูลทั้งหมดของสนามจะถูกลบไปด้วย",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((okx) => {
                if (okx) {

                    var strhref = "../query/field/f_del.php?id_field=" + code;
                    window.location.href = strhref;

                }
            });
    }
</script>