<script>
    $(document).ready(function() {
        $('#mng_dtime').DataTable({
            "aaSorting": [
                [0, 'ASC']
            ],
            //"lengthMenu":[[20,50, 100, -1], [20,50, 100,"All"]]
        });
    });
</script>
<script>
    $(document).on('draw.dt', function() {
        $('.md_edit').click(function() {
            var dt_code = $(this).attr('data-code');
            var dt_name = $(this).attr('data-name');
            var dt_time = $(this).attr('data-time');

            $('#dt_code').val(dt_code);
            $('#dt_name').val(dt_name);
            $('#dt_time').val(dt_time);

        });
    });
</script>
<script type="text/javascript">
    function delx(code) {
        swal({
                title: "คุณต้องลบข้อมูลเวลาจัดส่งใช่มั้ย ?",
                text: "ใบรายการขายและรายละเอียดทั้งหมดที่เกี่ยวข้องจะถูกลบไปด้วย",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((okx) => {
                if (okx) {

                    var strhref = "../query/dtime/dt_del.php?dt_code=" + code;
                    window.location.href = strhref;

                }
            });
    }
</script>