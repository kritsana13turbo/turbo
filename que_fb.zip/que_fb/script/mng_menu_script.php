<script>
    $(document).ready(function() {
        $('#mng_menu').DataTable({
            "aaSorting": [
                [0, 'ASC']
            ],
            //"lengthMenu":[[20,50, 100, -1], [20,50, 100,"All"]]
        });
    });
</script>
<script>
    $(document).on('draw.dt', function() {
        $('.md_edit').click(function() {
            var m_code = $(this).attr('data-code');
            var m_name = $(this).attr('data-name');
            var m_pic = $(this).attr('data-pic');
            var m_detail = $(this).attr('data-detail');
            var m_price = $(this).attr('data-price');

            $('#m_code').val(m_code);
            $('#m_name').val(m_name);
            $('#m_pic_show').attr("src","../img/menu/"+m_pic);
            $('#m_pic').val(m_pic);
            $('#m_detail').val(m_detail);
            $('#m_price').val(m_price);

        });
    });
</script>
<script type="text/javascript">
    function delx(code,pic) {
        swal({
                title: "คุณต้องลบข้อมูลเมนูใช่มั้ย ?",
                text: "รายละเอียดการขายที่เกี่ยวข้องจะถูกลบไปด้วย",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((okx) => {
                if (okx) {

                    var strhref = "../query/menu/m_del.php?m_code=" + code +"&m_pic=" + pic;
                    window.location.href = strhref;

                }
            });
    }
</script>