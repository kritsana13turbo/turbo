<script>
    $(document).ready(function() {
        $('#user_saleslip').DataTable({
            "aaSorting": [
                [0, 'ASC']
            ],
            //"lengthMenu":[[20,50, 100, -1], [20,50, 100,"All"]]
        });
    });
</script>
<script>
    $(document).on('draw.dt', function() {
        $('.md_view1').click(function() {
            var ss_code = $(this).attr('ss_code');
            var ss_time = $(this).attr('ss_time');
            var ss_totalprice = $(this).attr('ss_totalprice');
            var ss_discount = $(this).attr('ss_discount');
            var ss_netprice = $(this).attr('ss_netprice');
            var pm_method = $(this).attr('pm_method');
            var pm_pic = $(this).attr('pm_pic');
            var ss_status = $(this).attr('ss_status');
            var pm_status = $(this).attr('pm_status');
            var ss_note = $(this).attr('ss_note');
            var dt_code = $(this).attr('dt_code');
            var sa_code = $(this).attr('sa_code');
            var mb_code = $(this).attr('mb_code');


            $('#ss_code').val(ss_code);
            $('#ss_time').val(ss_time);
            $('#ss_totalprice').val(ss_totalprice);
            $('#ss_discount').val(ss_discount);
            $('#ss_netprice').val(ss_netprice);
            $('#pm_method').val(pm_method);
            if (pm_pic != '') {
                $('#pm_pic_view1').attr("src", "img/slip/" + pm_pic);
            } else {
                $('#pm_pic_view1').attr("src", "img/No-image-available.png");
            };
            $('#ss_status').val(ss_status);
            $('#pm_status').val(pm_status);
            $('#ss_note').val(ss_note);
            $('#dt_code').val(dt_code);
            $('#sa_code').val(sa_code);
            $('#mb_code').val(mb_code);

        });
    });
</script>

<script>
    $(document).on('draw.dt', function() {
        $('.md_view2').click(function() {
            var ss_code = $(this).attr('ss_code');

            $.ajax({
                url:"query/user/select_sale.php",
                type: 'POST',
                data: {
                    'id': ss_code
                },
                success: function(result) {
                    $('.sale_table').html(result);
                }
            });



        });
    });
</script>
<script type="text/javascript">
    function delx(code) {
        swal({
                title: "ต้องการยกเลิกคำสั่งซื้อใช่หรือไม่ ?",
                text: "หากคำสั่งซื้อถูกอนุมัติแล้วจะไม่สามารถยกเลิกได้",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((okx) => {
                if (okx) {

                    var strhref = "query/user/ss_cancel.php?ss_code=" + code;
                    window.location.href = strhref;

                }
            });
    }
</script>