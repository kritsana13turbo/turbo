<script>
    $(document).ready(function() {
        $('#mng_member').DataTable({
            "aaSorting": [
                [0, 'ASC']
            ],
            //"lengthMenu":[[20,50, 100, -1], [20,50, 100,"All"]]
        });
    });
</script>
<script>
    $(document).on('draw.dt', function() {
        $('.md_edit').click(function() {
            var mb_code = $(this).attr('data-code');
            var mb_email = $(this).attr('data-email');
            var mb_pass = $(this).attr('data-pass');
            var mb_name = $(this).attr('data-name');
            var mb_phone = $(this).attr('data-phone');
            var mb_type = $(this).attr('data-type');

            $('#mb_code').val(mb_code);
            $('#mb_email').val(mb_email);
            $('#mb_pass').val(mb_pass);
            $('#mb_name').val(mb_name);
            $('#mb_phone').val(mb_phone);
            $('#mb_type').val(mb_type);

        });
    });
</script>
<script type="text/javascript">
    function delx(code) {
        swal({
                title: "คุณต้องลบข้อมูลสมาชิกใช่มั้ย ?",
                text: "ที่อยู่,รายการขายทั้งหมดของสมาชิกท่านนี้จะถูกลบไปด้วย",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((okx) => {
                if (okx) {

                    var strhref = "../query/member/mb_del.php?mb_code=" + code;
                    window.location.href = strhref;

                }
            });
    }
</script>