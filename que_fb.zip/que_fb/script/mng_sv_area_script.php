<script>
    $(document).ready(function() {
        $('#mng_sv_area').DataTable({
            "aaSorting": [
                [0, 'ASC']
            ],
            //"lengthMenu":[[20,50, 100, -1], [20,50, 100,"All"]]
        });
    });
</script>
<script>
    $(document).on('draw.dt', function() {
        $('.md_edit').click(function() {
            var sa_code = $(this).attr('data-code');
            var sa_name = $(this).attr('data-name');
            var sa_cost = $(this).attr('data-cost');

            $('#sa_code').val(sa_code);
            $('#sa_name').val(sa_name);
            $('#sa_cost').val(sa_cost);

        });
    });
</script>
<script type="text/javascript">
    function delx(code) {
        swal({
                title: "คุณต้องลบข้อมูลพื้นที่ใช่มั้ย ?",
                text: "ใบรายการขายและรายละเอียดทั้งหมดที่เกี่ยวข้องจะถูกลบไปด้วย",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((okx) => {
                if (okx) {

                    var strhref = "../query/sv_area/sa_del.php?sa_code=" + code;
                    window.location.href = strhref;

                }
            });
    }
</script>