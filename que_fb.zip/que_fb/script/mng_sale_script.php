<script>
    $(document).ready(function() {
        $('#mng_sale').DataTable({
            "aaSorting": [
                [0, 'ASC']
            ],
            //"lengthMenu":[[20,50, 100, -1], [20,50, 100,"All"]]
        });
    });
</script>
<script>
    $(document).on('draw.dt', function() {
        $('.md_edit').click(function() {
            var s_code = $(this).attr('s_code');
            var s_total = $(this).attr('s_total');
            var s_price = $(this).attr('s_price');
            var m_code = $(this).attr('m_code');
            var ss_code = $(this).attr('ss_code');

            $('#s_code').val(s_code);
            $('#s_total').val(s_total);
            $('#s_price').val(s_price);
            $('#m_code').val(m_code);
            $('#ss_code').val(ss_code);

        });
    });
</script>
<script type="text/javascript">
    function delx(code) {
        swal({
                title: "คุณต้องลบรายละเอียดการขายใช่มั้ย ?",
                text: "หากต้องการลบให้กด OK",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            })
            .then((okx) => {
                if (okx) {

                    var strhref = "../query/sale/s_del.php?s_code=" + code;
                    window.location.href = strhref;

                }
            });
    }
</script>