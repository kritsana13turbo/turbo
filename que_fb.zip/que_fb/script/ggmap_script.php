<script type="text/javascript">
        var initialLocation;
            var bangkok = new google.maps.LatLng(13.755716, 100.501589);
            function initialize() {
                var myOptions = {
                    zoom: 15,
                    //center: latlng,
                    mapTypeControl: true,
                    navigationControlOptions: {style: google.maps.NavigationControlStyle.SMALL},
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                var map = new google.maps.Map(document.getElementById("map_canvas"),
                myOptions);

                // detect geolocation lat/lng
                if ( navigator.geolocation ) {
                    navigator.geolocation.getCurrentPosition(function(location) {
                        var location = location.coords;
                        initialLocation = new google.maps.LatLng(location.latitude, location.longitude);
                        map.setCenter(initialLocation);
                        setMarker(initialLocation);
                    }, function() {
                        handleNoGeolocation();
                    });
                } else {
                    handleNoGeolocation();
                }

                // no geolocation
                function handleNoGeolocation() {
                    map.setCenter(bangkok);
                    setMarker(bangkok);
                }

                // set marker
                function setMarker(initialName) {
                    var marker = new google.maps.Marker({
                        draggable: true,
                        position: initialName,
                        map: map,
                        title: "คุณอยู่ที่นี่."
                    });
                    google.maps.event.addListener(marker, 'dragend', function(event) {
                        $("#ad_lat").val(marker.getPosition().lat());
                        $("#ad_lon").val(marker.getPosition().lng());
                    });
                }
            }

            function edit_map_addr(lat,lon) {
                var old_crood = new google.maps.LatLng(lat, lon);
                var myOptions = {
                    zoom: 15,
                    //center: latlng,
                    mapTypeControl: true,
                    navigationControlOptions: {style: google.maps.NavigationControlStyle.SMALL},
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                var map_edit = new google.maps.Map(document.getElementById("edit_map_addr"),
                myOptions);

                    map_edit.setCenter(old_crood);
                    setMarkerEdit(old_crood);



                // set marker
                function setMarkerEdit(initialName) {
                    var marker_edit = new google.maps.Marker({
                        draggable: true,
                        position: initialName,
                        map: map_edit,
                        title: "คุณอยู่ที่นี่."
                    });
                    google.maps.event.addListener(marker_edit, 'dragend', function(event) {
                        $("#ad_lat_edit").val(marker_edit.getPosition().lat());
                        $("#ad_lon_edit").val(marker_edit.getPosition().lng());
                    });
                }
            }

            $(document).ready(function() {
                initialize();
            });
        </script>