<script type="text/javascript">
    function edit_map_addr(lat, lon) {
        var old_crood = new google.maps.LatLng(lat, lon);
        var myOptions = {
            zoom: 15,
            //center: latlng,
            mapTypeControl: true,
            navigationControlOptions: {
                style: google.maps.NavigationControlStyle.SMALL
            },
            mapTypeId: google.maps.MapTypeId.ROADMAP
        };
        var map_edit = new google.maps.Map(document.getElementById("edit_map_addr"),
            myOptions);

        map_edit.setCenter(old_crood);
        setMarkerEdit(old_crood);



        // set marker
        function setMarkerEdit(initialName) {
            var marker_edit = new google.maps.Marker({
                draggable: true,
                position: initialName,
                map: map_edit,
                title: "คุณอยู่ที่นี่."
            });

            google.maps.event.addListener(marker_edit, 'dragend', function(event)  {
                $("#ad_lat_edit").val(marker_edit.getPosition().lat());
                $("#ad_lon_edit").val(marker_edit.getPosition().lng());

            });
        }
    }

</script>

    
